"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CheckCircle2, ChevronRight, Crown, Users, Wallet, Box, LayoutGrid, Table as TableIcon, Zap, Calendar, Shield, Star, ArrowRight } from "lucide-react"
import Link from "next/link"
import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useOrder } from "@/context/OrderContext"
import { useRouter } from "next/navigation"
import { cn } from "@/lib/utils"

export interface Plan {
  name:string; price:string; credits:string; rate:string
  validity:string; isPopular?:boolean; colorTheme?:string
}

export function PlansHeader() {
  return (
    <div className="page-header mb-8">
      <div className="page-header-icon">
        <Wallet className="h-5 w-5" />
      </div>
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Pricing Plans</h1>
        <p className="text-sm text-slate-500 mt-0.5">Choose the perfect plan for your messaging needs</p>
      </div>
    </div>
  )
}

/* ── Soft stat overview cards ── */
const overviewCards = [
  { label:"Total Plans",    key:"total",    bg:"#EFF6FF", border:"#BFDBFE", text:"#1D4ED8", iconBg:"#DBEAFE", icon:Box,    href:"/plans" },
  { label:"Reseller Plans", key:"reseller", bg:"#F5F3FF", border:"#DDD6FE", text:"#6D28D9", iconBg:"#EDE9FE", icon:Crown,  href:"/plans/reseller-plans" },
  { label:"User Plans",     key:"user",     bg:"#F0FDF4", border:"#BBF7D0", text:"#15803D", iconBg:"#DCFCE7", icon:Users,  href:"/plans/user-plans" },
  { label:"Avg Price",      key:"avg",      bg:"#FFFBEB", border:"#FDE68A", text:"#B45309", iconBg:"#FEF3C7", icon:Wallet, href:"/plans" },
]

export function PlansOverview() {
  const values: Record<string,string> = { total:"9", reseller:"3", user:"6", avg:"₹22,214" }
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8 stagger">
      {overviewCards.map((c)=>{
        const Icon = c.icon
        return (
          <Link key={c.key} href={c.href}>
            <div className="rounded-2xl p-5 border flex items-start justify-between gap-3 cursor-pointer transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lg"
              style={{background:c.bg, borderColor:c.border}}>
              <div>
                <p className="text-xs font-semibold uppercase tracking-wide mb-2" style={{color:c.text,opacity:.65}}>{c.label}</p>
                <p className="text-2xl font-bold tracking-tight" style={{color:c.text}}>{values[c.key]}</p>
              </div>
              <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{background:c.iconBg}}>
                <Icon className="h-5 w-5" style={{color:c.text}} />
              </div>
            </div>
          </Link>
        )
      })}
    </div>
  )
}

/* ── Plan list header with view toggle ── */
interface PlansListHeaderProps { view:"card"|"table"; setView:(v:"card"|"table")=>void; total:number }
export function PlansListHeader({ view, setView, total }: PlansListHeaderProps) {
  return (
    <div className="flex items-center justify-between mb-5">
      <div className="flex items-center gap-2.5">
        <div className="page-header-icon w-8 h-8">
          <LayoutGrid className="h-4 w-4" />
        </div>
        <h2 className="text-sm font-semibold text-slate-800">
          All Plans
          <span className="ml-2 text-xs text-slate-400 font-normal bg-slate-100 px-2 py-0.5 rounded-full">{total} found</span>
        </h2>
      </div>
      <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
        {(["card","table"] as const).map((v)=>(
          <button key={v} onClick={()=>setView(v)}
            className={cn("flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all",
              view===v ? "bg-white text-slate-800 shadow-sm" : "text-slate-500 hover:text-slate-700")}>
            {v==="card" ? <LayoutGrid className="h-3.5 w-3.5" /> : <TableIcon className="h-3.5 w-3.5" />}
            {v==="card" ? "Card View" : "Table View"}
          </button>
        ))}
      </div>
    </div>
  )
}

/* ── Plan table row ── */
interface PlanTableProps { plans:any[] }
export function PlanTable({ plans }: PlanTableProps) {
  const { setOrder } = useOrder()
  const router = useRouter()
  const handleSelect = (plan:any) => {
    setOrder({ planName:plan.name, planType:plan.type, planPrice:plan.price })
    router.push(`/plans/checkout?planName=${encodeURIComponent(plan.name)}`)
  }
  return (
    <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden" style={{boxShadow:"0 1px 3px rgba(0,0,0,0.06)"}}>
      <Table>
        <TableHeader>
          <TableRow className="bg-slate-50/80 hover:bg-slate-50/80">
            {["Plan Name","Type","Price","Credits","Rate","Validity","Action"].map((h,i)=>(
              <TableHead key={h} className={cn("py-3.5 text-[11px] font-semibold uppercase tracking-wide text-slate-400",
                i===0&&"pl-6", i===6&&"text-right pr-6")}>{h}</TableHead>
            ))}
          </TableRow>
        </TableHeader>
        <TableBody>
          {plans.map((plan,i)=>(
            <TableRow key={i} className="tr-hover border-slate-50">
              <TableCell className="py-4 pl-6">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold text-slate-800">{plan.name}</span>
                  {plan.isPopular && (
                    <span className="bg-[#F0FDF9] text-[#128C7E] border border-[#A7F3D0] text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wide">Popular</span>
                  )}
                </div>
              </TableCell>
              <TableCell>
                <span className={cn("text-[11px] font-semibold rounded-full px-2.5 py-0.5",
                  plan.category==="reseller"
                    ? "bg-purple-50 text-purple-700 border border-purple-200"
                    : "bg-green-50 text-green-700 border border-green-200")}>
                  {plan.category==="reseller"?"Reseller":"User"}
                </span>
              </TableCell>
              <TableCell><span className="text-sm font-semibold text-slate-800">₹{plan.price}</span></TableCell>
              <TableCell><span className="text-sm text-slate-600">{plan.credits}</span></TableCell>
              <TableCell><span className="text-sm text-slate-500">{plan.rate}</span></TableCell>
              <TableCell><span className="text-sm text-slate-500">{plan.validity}</span></TableCell>
              <TableCell className="pr-6 text-right">
                {plan.isDemo ? (
                  <span className="text-xs text-slate-400 font-medium">Demo</span>
                ) : (
                  <button onClick={()=>handleSelect(plan)}
                    className="h-8 px-4 rounded-xl text-xs font-semibold text-white transition-all hover:-translate-y-px"
                    style={{background:"#128C7E",boxShadow:"0 2px 8px rgba(18,140,126,.25)"}}>
                    Select
                  </button>
                )}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}
