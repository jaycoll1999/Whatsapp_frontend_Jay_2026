import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { usePathname, useRouter } from "next/navigation"
import {
    LayoutGrid, User, Code, ShoppingCart,
    CreditCard, Users, History, LogOut,
    ChevronRight, X, MessageSquare
} from "lucide-react"
import { cn } from "@/lib/utils"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

const navGroups = [
    {
        label: "Overview",
        items: [
            { icon: LayoutGrid,   label: "Dashboard",        href: "/dashboard/reseller/analytics", color: "text-teal-600" },
            { icon: User,         label: "Profile",           href: "/dashboard/reseller/profile",   color: "text-slate-500" },
        ]
    },
    {
        label: "Management",
        items: [
            { icon: Users,        label: "Users",             href: "/dashboard/reseller/users",     color: "text-slate-500" },
            { icon: CreditCard,   label: "Plans",             href: "/dashboard/reseller/plans",     color: "text-slate-500" },
            { icon: ShoppingCart, label: "My Orders",         href: "/dashboard/reseller/orders",    color: "text-slate-500" },
        ]
    },
    {
        label: "Tools",
        items: [
            { icon: Code,         label: "API",               href: "https://documenter.getpostman.com/view/1240173/2sB3B8stEM", color: "text-slate-500", external: true },
            { icon: History,      label: "Activity History",  href: "/dashboard/reseller/history",   color: "text-slate-500" },
        ]
    },
]

interface SidebarProps {
    collapsed: boolean
    toggleSidebar: () => void
}

export function Sidebar({ collapsed, toggleSidebar }: SidebarProps) {
    const pathname = usePathname()
    const router = useRouter()
    const [userId, setUserId] = useState<string | null>(null)
    const [userName, setUserName] = useState<string>("User")

    useEffect(() => {
        if (typeof window !== "undefined") {
            const storedId = localStorage.getItem("reseller_id") || localStorage.getItem("user_id")
            if (storedId && storedId !== "undefined") setUserId(storedId)
        }
    }, [])

    const handleSignOut = () => router.push("/login")

    const initials = userName
        .split(" ")
        .map((n) => n[0])
        .join("")
        .toUpperCase()
        .substring(0, 2) || "U"

    return (
        <div className={cn(
            "h-screen bg-white border-r border-slate-100 flex flex-col fixed left-0 top-0",
            "transition-all duration-300 ease-in-out z-20 shadow-[1px_0_12px_rgba(0,0,0,0.04)]",
            collapsed ? "w-16" : "w-64"
        )}>

            {/* ── Logo ── */}
            <div className={cn(
                "flex items-center border-b border-slate-100 h-[65px] shrink-0",
                collapsed ? "justify-center px-2" : "px-5 gap-2.5 justify-between"
            )}>
                {!collapsed && (
                    <>
                        <div className="flex items-center gap-2.5 min-w-0">
                            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#128C7E] to-[#25D366] flex items-center justify-center shrink-0 shadow-sm shadow-teal-200">
                                <MessageSquare className="w-4 h-4 text-white" />
                            </div>
                            <div className="min-w-0">
                                <p className="font-bold text-[15px] text-slate-800 truncate leading-tight">Message API</p>
                                <p className="text-[10px] text-teal-600 font-semibold tracking-wide leading-tight">WhatsApp Platform</p>
                            </div>
                        </div>
                        <button
                            onClick={toggleSidebar}
                            className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-400 transition-colors shrink-0"
                        >
                            <X className="h-4 w-4" />
                        </button>
                    </>
                )}

                {collapsed && (
                    <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#128C7E] to-[#25D366] flex items-center justify-center shadow-sm shadow-teal-200">
                        <MessageSquare className="w-4 h-4 text-white" />
                    </div>
                )}
            </div>

            {/* Expand handle when collapsed */}
            {collapsed && (
                <button
                    onClick={toggleSidebar}
                    className="absolute -right-3 top-[76px] bg-white border border-slate-200 shadow-sm rounded-full p-1 text-slate-400 hover:text-slate-700 hover:border-slate-300 transition-colors z-10"
                >
                    <ChevronRight className="h-3 w-3" />
                </button>
            )}

            {/* ── Nav ── */}
            <nav className="flex-1 py-3 px-2 overflow-y-auto space-y-4">
                {navGroups.map((group) => (
                    <div key={group.label}>
                        {!collapsed && (
                            <p className="section-label px-3 mb-1.5">{group.label}</p>
                        )}
                        <div className="space-y-0.5">
                            {group.items.map((item) => {
                                const isActive = pathname === item.href
                                return (
                                    <Link
                                        key={item.label}
                                        href={item.href}
                                        target={item.external ? "_blank" : undefined}
                                        rel={item.external ? "noopener noreferrer" : undefined}
                                        title={collapsed ? item.label : undefined}
                                        className={cn(
                                            "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all duration-150 group relative",
                                            isActive
                                                ? "nav-active"
                                                : "text-slate-600 hover:bg-slate-50 hover:text-slate-900",
                                            collapsed && "justify-center px-0"
                                        )}
                                    >
                                        <item.icon className={cn(
                                            "h-[18px] w-[18px] shrink-0 transition-colors",
                                            isActive ? "text-[#128C7E]" : "text-slate-400 group-hover:text-slate-600"
                                        )} />
                                        {!collapsed && (
                                            <span className={cn(
                                                "text-[13.5px]",
                                                isActive ? "text-[#0e7468]" : "text-slate-600 group-hover:text-slate-800"
                                            )}>
                                                {item.label}
                                            </span>
                                        )}
                                        {isActive && !collapsed && (
                                            <span className="ml-auto w-1.5 h-1.5 rounded-full bg-[#128C7E] pulse-dot" />
                                        )}
                                    </Link>
                                )
                            })}
                        </div>
                    </div>
                ))}
            </nav>

            {/* ── Bottom: User + Sign out ── */}
            <div className="border-t border-slate-100 p-3 space-y-1 shrink-0">
                {!collapsed ? (
                    <>
                        <Link
                            href="/dashboard/reseller/profile"
                            className="flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-slate-50 transition-colors group"
                        >
                            <Avatar className="h-8 w-8 shrink-0">
                                <AvatarFallback className="text-xs font-bold bg-gradient-to-br from-[#128C7E] to-[#25D366] text-white">
                                    {initials}
                                </AvatarFallback>
                            </Avatar>
                            <div className="flex-1 min-w-0">
                                <p className="text-[13px] font-semibold text-slate-800 truncate leading-tight">{userName}</p>
                                <p className="text-[11px] text-slate-400 truncate leading-tight font-mono">
                                    {userId ? userId.substring(0, 16) + "…" : "—"}
                                </p>
                            </div>
                        </Link>
                        <button
                            onClick={handleSignOut}
                            className="flex items-center gap-2.5 w-full px-3 py-2 rounded-xl text-[13px] text-red-500 hover:bg-red-50 hover:text-red-600 transition-colors font-medium"
                        >
                            <LogOut className="h-4 w-4" />
                            Sign Out
                        </button>
                    </>
                ) : (
                    <div className="flex flex-col items-center gap-2 py-1">
                        <Link href="/dashboard/reseller/profile" title="Profile">
                            <Avatar className="h-8 w-8 cursor-pointer hover:opacity-80 transition-opacity">
                                <AvatarFallback className="text-xs font-bold bg-gradient-to-br from-[#128C7E] to-[#25D366] text-white">
                                    {initials}
                                </AvatarFallback>
                            </Avatar>
                        </Link>
                        <button
                            onClick={handleSignOut}
                            title="Sign Out"
                            className="p-2 rounded-xl text-red-400 hover:bg-red-50 hover:text-red-500 transition-colors"
                        >
                            <LogOut className="h-4 w-4" />
                        </button>
                    </div>
                )}
            </div>
        </div>
    )
}
