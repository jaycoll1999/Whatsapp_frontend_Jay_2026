"use client"

import { useState, useEffect, useRef } from "react"
import { usePathname, useRouter } from "next/navigation"
import { Sidebar }     from "@/components/layout/Sidebar"
import { UserSidebar } from "@/components/layout/UserSidebar"

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
    const pathname = usePathname()
    const router   = useRouter()
    const [collapsed, setCollapsed] = useState(false)
    const [pageKey,   setPageKey]   = useState(pathname)
    const prevPath = useRef(pathname)

    const isUser = pathname.startsWith("/dashboard/user")

    /* page transition key */
    useEffect(() => {
        if (prevPath.current !== pathname) {
            setPageKey(pathname)
            prevPath.current = pathname
        }
    }, [pathname])

    /* role guard */
    useEffect(() => {
        const role  = localStorage.getItem("user_role")
        const token = localStorage.getItem("token") || localStorage.getItem("resellerToken")
        if (!token) { router.push("/login"); return }
        if (!role)  return
        const r = role.toLowerCase()
        if (r === "reseller" && pathname.startsWith("/dashboard/user"))
            router.push("/dashboard/reseller/analytics")
        else if ((r === "user" || r === "business_owner") && pathname.startsWith("/dashboard/reseller"))
            router.push("/dashboard/user")
    }, [pathname, router])

    const sidebarW = collapsed ? "4rem" : "16rem"

    return (
        /* ── canvas: warm off-white so white cards pop ── */
        <div className="min-h-screen flex" style={{ background:"#F5F7FA" }}>

            {isUser
                ? <UserSidebar collapsed={collapsed} toggleSidebar={() => setCollapsed(p => !p)} />
                : <Sidebar     collapsed={collapsed} toggleSidebar={() => setCollapsed(p => !p)} />
            }

            <main
                key={pageKey}
                className="flex-1 min-w-0 overflow-x-hidden page-enter"
                style={{
                    marginLeft: sidebarW,
                    transition: "margin-left 0.3s cubic-bezier(0.22,1,0.36,1)",
                    padding: "1.5rem",
                    minHeight: "100vh",
                }}
            >
                {children}
            </main>
        </div>
    )
}
