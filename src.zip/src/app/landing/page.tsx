"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ChevronLeft, ChevronRight, Quote } from "lucide-react"

function FaqItem({ q, a }: { q: string; a: string }) {
    const [open, setOpen] = useState(false)
    return (
        <div style={{ borderBottom: "1px solid #F1F5F9" }}>
            <button
                onClick={() => setOpen(!open)}
                style={{
                    width: "100%", display: "flex", justifyContent: "space-between", alignItems: "center",
                    padding: "24px 16px", background: "none", border: "none", cursor: "pointer",
                    fontFamily: "'Oswald', sans-serif", fontSize: "16px", fontWeight: 600,
                    color: open ? "#22C55E" : "#334155", textAlign: "left", textTransform: "uppercase",
                    letterSpacing: "0.02em", transition: "color .2s"
                }}
            >
                {q}
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={open ? "#22C55E" : "#94A3B8"} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
                    style={{ flexShrink: 0, transform: open ? "rotate(180deg)" : "rotate(0deg)", transition: "transform .3s" }}>
                    <polyline points="6 9 12 15 18 9" />
                </svg>
            </button>
            {open && (
                <div style={{ padding: "0 16px 24px" }}>
                    <p style={{ fontSize: "15px", fontWeight: 700, color: "#64748B", fontStyle: "italic", lineHeight: 1.65 }}>{a}</p>
                </div>
            )}
        </div>
    )
}

function Logo({ light = false }: { light?: boolean }) {
    return (
        <div style={{ display: "flex", alignItems: "center", gap: "12px", cursor: "pointer" }}>
            <div style={{
                width: "44px", height: "44px", background: "#22C55E", borderRadius: "50%",
                display: "flex", alignItems: "center", justifyContent: "center",
                boxShadow: "0 4px 12px rgba(34,197,94,0.2)"
            }}>
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M3 21l1.65-3.8A9 9 0 1 1 20.25 10.25 9 9 0 0 1 17.25 17.25l-1.65 1.65L3 21z" />
                </svg>
            </div>
            <div style={{ display: "flex", flexDirection: "column", lineHeight: 1, fontFamily: "'Outfit', sans-serif" }}>
                <span style={{ fontSize: "20px", fontWeight: 700, color: light ? "#fff" : "#111827", letterSpacing: "-0.01em" }}>Message API</span>
                <span style={{ fontSize: "11px", fontWeight: 700, color: "#22C55E", textTransform: "uppercase", letterSpacing: "0.05em", marginTop: "2px" }}>WhatsApp Platform</span>
            </div>
        </div>
    )
}

export default function LandingPage() {
    const router = useRouter();
    const [testimonialIndex, setTestimonialIndex] = useState(0);

    const testimonials = [
        { text: "I am delighted to use the unlimited plan of messageapi for my BUSY ERP.", logo: "/logos/talaro.jpg", name: "ERP Solutions" },
        { text: "We recommend messageapi to all businessowners for google sheet campaign & automation.", logo: "/logos/market_brand.jpg", name: "Vedant Soft" },
        { text: "If anyone is looking for free database for campaigns then check whatsapp group manager in messageapi.", logo: "/logos/jmj_book_store.jpg", name: "United Solutionz" },
        { text: "Tracking and analyzing team performance through chat replies capture is the best feature of messageapi.", logo: "/logos/mandapam.png", name: "GBS" },
        { text: "Sending payment reminders from Tally is the most powerful feature of messageapi.", logo: "/logos/safe_t_net.png", name: "iDream" },
    ];

    const nextTestimonial = () => {
        setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    };

    const prevTestimonial = () => {
        setTestimonialIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
    };

    return (
        <>
            <style>{`
                @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&family=Outfit:wght@400;500;600;700;800&display=swap');
                *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
                :root{
                    --green:#22C55E;--green-dark:#16A34A;--green-light:#DCFCE7;
                    --blue:#2563EB;--blue-dark:#1D4ED8;
                    --red:#DC2626;--cyan:#0891B2;--purple:#7C3AED;
                    --slate-900:#0F172A;--slate-800:#1E293B;--slate-700:#334155;
                    --slate-600:#475569;--slate-500:#64748B;--slate-400:#94A3B8;
                    --slate-200:#E2E8F0;--slate-100:#F1F5F9;--slate-50:#F8FAFC;
                    --white:#FFFFFF;
                }
                html{scroll-behavior:smooth}
                body{font-family:'Inter',sans-serif;color:#1E293B;background:#fff;overflow-x:hidden;font-weight:400;line-height:1.5}
                h1,h2,h3,h4{font-family:'Outfit',sans-serif;letter-spacing:-0.01em;font-weight:700}
                a{text-decoration:none;color:inherit}
                .badge-pill:hover{background:#22C55E;color:#fff;border-color:#22C55E}
                .feature-card:hover{box-shadow:0 20px 50px rgba(0,0,0,.07);transform:translateY(-2px)}
                .feature-card:hover .feature-icon{background:#22C55E;color:#fff}
                .key-card:hover{transform:scale(1.03)}
                .btn:hover{transform:translateY(-1px);filter:brightness(1.08)}
                .use-card:hover{background:#0F172A}
                .use-card:hover .use-icon{background:#22C55E}
                .social-btn:hover{background:#22C55E;color:#fff}
                .footer-col ul li a:hover{color:#22C55E}
                .nav-links a:hover,.nav-dd:hover{color:#2563EB}
                .font-inter{font-family:'Inter',sans-serif !important}
                .font-outfit{font-family:'Outfit',sans-serif !important}

            `}</style>

            <div style={{ fontFamily: "'Inter', sans-serif", color: "#1E293B", background: "#fff", overflowX: "hidden" }}>

                {/* ===== NAVBAR ===== */}
                <nav style={{
                    position: "fixed", top: 0, left: 0, right: 0, height: "80px",
                    background: "#fff", borderBottom: "1px solid #F1F5F9",
                    zIndex: 100, display: "flex", alignItems: "center",
                    padding: "0 60px"
                }}>
                    {/* Logo */}
                    <Logo />

                    <div style={{ flex: 1 }}></div>

                    {/* Nav Links */}
                    <div className="nav-links" style={{ display: "flex", alignItems: "center", gap: "40px", marginRight: "40px" }}>
                        {["Home", "Pricing"].map(l => (
                            <a key={l} href="#" style={{ fontSize: "15px", fontWeight: 700, color: "#334155", transition: "color .2s" }}>{l}</a>
                        ))}
                    </div>

                    {/* Buttons */}
                    <div style={{ display: "flex", gap: "12px" }}>
                        <button
                            onClick={() => router.push('/login')}
                            style={{ background: "#2563EB", color: "#fff", border: "none", borderRadius: "8px", padding: "10px 24px", fontWeight: 700, fontSize: "14px", cursor: "pointer" }}
                        >Log in</button>
                        <button
                            onClick={() => router.push('/register')}
                            style={{ background: "#DC2626", color: "#fff", border: "none", borderRadius: "8px", padding: "10px 24px", fontWeight: 700, fontSize: "14px", cursor: "pointer" }}
                        >Sign up</button>
                    </div>
                </nav>


                {/* ===== HERO ===== */}
                <section style={{ padding: "120px 40px 60px", background: "linear-gradient(180deg, #F8FAFC 0%, #FFFFFF 100%)", textAlign: "center" }}>
                    <h1 style={{ fontSize: "clamp(28px,5vw,52px)", fontWeight: 800, color: "#111827", textTransform: "uppercase", lineHeight: 1.1, marginBottom: "20px", letterSpacing: "-1px" }}>
                        WHATSAPP <span style={{ color: "#22C55E" }}>BUSINESS</span> API SOLUTION
                    </h1>
                    <p style={{ fontSize: "clamp(14px,2vw,22px)", fontWeight: 600, color: "#64748B", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: "40px" }}>
                        SEND WHATSAPP FROM ANY ERP OR POS
                    </p>
                    <div style={{ display: "flex", justifyContent: "center", gap: "20px", marginBottom: "80px" }}>
                        <button
                            onClick={() => router.push('/register')}
                            className="btn" style={{ height: "56px", padding: "0 40px", borderRadius: "12px", border: "none", fontWeight: 800, fontSize: "15px", background: "#22C55E", color: "#fff", cursor: "pointer", transition: "transform .2s", boxShadow: "0 10px 20px rgba(34,197,94,0.3)" }}
                        >Sign Up</button>
                        <button className="btn" style={{ height: "56px", padding: "0 40px", borderRadius: "12px", border: "2px solid #E2E8F0", fontWeight: 800, fontSize: "15px", background: "#fff", color: "#1E293B", cursor: "pointer", transition: "transform .2s" }}>Watch Video</button>
                    </div>

                    {/* Mockup Container */}
                    <div style={{ maxWidth: "800px", margin: "0 auto", position: "relative" }}>
                        <div style={{ background: "#F1F5F9", borderRadius: "24px", padding: "12px", border: "1px solid #E2E8F0", boxShadow: "0 50px 100px -20px rgba(0,0,0,0.12)" }}>
                            <div style={{ background: "#fff", borderRadius: "16px", overflow: "hidden", position: "relative" }}>
                                <img
                                    src="/integration_mockup.png"
                                    alt="Platform Demo"
                                    style={{ width: "100%", height: "auto", display: "block" }}
                                />
                                {[
                                    { label: "Sidebar Control", bg: "#3B82F6", style: { top: "14%", left: "6%" } },
                                    { label: "Live Chat", bg: "#EF4444", style: { top: "30%", right: "9%" } },
                                    { label: "Analytics Bot", bg: "#22C55E", style: { bottom: "20%", left: "22%" } },
                                    { label: "Notification", bg: "#F59E0B", style: { top: "8%", right: "38%" } },
                                ].map(b => (
                                    <span key={b.label} style={{ position: "absolute", padding: "4px 12px", borderRadius: "20px", fontSize: "9px", fontWeight: 900, color: "#fff", textTransform: "uppercase", fontFamily: "'Oswald', sans-serif", letterSpacing: "0.08em", background: b.bg, ...b.style, boxShadow: "0 4px 12px rgba(0,0,0,0.15)" }}>{b.label}</span>
                                ))}
                            </div>
                        </div>
                    </div>
                </section>

                {/* ===== MOBILL PRINTER MARQUEE ===== */}
                <section style={{ padding: "60px 40px", textAlign: "center", background: "#fff" }}>
                    <h2 style={{ fontSize: "clamp(28px,4vw,48px)", fontWeight: 800, color: "#111827", marginBottom: "8px", fontFamily: "'Outfit', sans-serif" }}>Mobill Printer</h2>
                    <h2 style={{ fontSize: "clamp(36px,6vw,60px)", fontWeight: 800, color: "#22C55E", textTransform: "uppercase", marginBottom: "20px", letterSpacing: "-0.01em", fontFamily: "'Outfit', sans-serif" }}>DIGITAL BILL SENDER</h2>
                    <p style={{ fontSize: "16px", fontWeight: 500, color: "#6B7280", maxWidth: "700px", margin: "0 auto", lineHeight: 1.5 }}>
                        Send bills, invoices, and warranty documents directly via WhatsApp from any desktop, ERP, or POS system.
                    </p>
                </section>

                {/* ===== KEY FEATURES ===== */}
                <section style={{ padding: "80px 40px", background: "#f8fafc" }}>
                    <div style={{ maxWidth: "1100px", margin: "0 auto", textAlign: "center" }}>
                        <h2 style={{ fontSize: "20px", fontWeight: 800, color: "#111827", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: "40px" }}>Key Features</h2>

                        <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: "20px" }}>
                            {[
                                { title: "Digital Bill", desc: "Replace paper invoices with digital bills sent directly to customers via WhatsApp", icon: <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /> },
                                { title: "Reach Any Contact", desc: "Send to both saved and unsaved WhatsApp contacts with ease", icon: <rect x="5" y="2" width="14" height="20" rx="2" ry="2" /> },
                                { title: "QR Warranty System", desc: "Send QR codes as warranty documents for seamless customer service", icon: <><rect x="3" y="3" width="7" height="7" /><rect x="14" y="3" width="7" height="7" /><rect x="14" y="14" width="7" height="7" /><rect x="3" y="14" width="7" height="7" /></> },
                                { title: "Marketing Integration", desc: "Send templated promotion messages with bills and vouchers", icon: <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z" /> },
                                { title: "Customer Database", desc: "Automatically save customer numbers to build your business database", icon: <circle cx="12" cy="12" r="10" /> },
                                { title: "Simple Setup", desc: "One-time installation on Windows 10 or higher systems", icon: <polyline points="20 6 9 17 4 12" /> },
                            ].map((f, i) => (
                                <div key={i} style={{ padding: "30px", background: "#fff", borderRadius: "20px", textAlign: "left", boxShadow: "0 8px 24px rgba(0,0,0,0.04)", border: "1px solid #f1f5f9" }}>
                                    <div style={{ width: "20px", height: "20px", color: "#22C55E", marginBottom: "16px" }}>
                                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">{f.icon}</svg>
                                    </div>
                                    <h3 style={{ fontSize: "16px", fontWeight: 700, color: "#1F2937", marginBottom: "10px" }}>{f.title}</h3>
                                    <p style={{ fontSize: "13px", fontWeight: 500, color: "#6B7280", lineHeight: 1.5 }}>{f.desc}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                </section>

                {/* ===== IDEAL FOR ===== */}
                <section style={{ padding: "60px 40px", background: "#fff" }}>
                    <div style={{ maxWidth: "1000px", margin: "0 auto", textAlign: "center" }}>
                        <h2 style={{ fontSize: "20px", fontWeight: 800, color: "#111827", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: "40px", fontFamily: "'Outfit', sans-serif" }}>Ideal For</h2>

                        <div style={{ background: "#F8FAFC", borderRadius: "24px", padding: "40px", textAlign: "left" }}>
                            <div style={{ display: "flex", flexDirection: "column", gap: "32px" }}>
                                {[
                                    { id: 1, title: "Food & Retail Businesses", desc: "Restaurants, supermarkets, and specialty shops looking to eliminate paper billing" },
                                    { id: 2, title: "Electronics & Appliance Retailers", desc: "Consumer durables, appliances, and mobile stores for digital warranty management" },
                                    { id: 3, title: "Small & Medium Businesses", desc: "Any business seeking an alternative to traditional paper invoicing and warranty systems" },
                                    { id: 4, title: "Consumer Brands", desc: "Branded companies upgrading to low-cost QR-based warranty delivery through trade channels" },
                                ].map((item) => (
                                    <div key={item.id} style={{ display: "flex", gap: "20px", alignItems: "flex-start" }}>
                                        <div style={{ width: "32px", height: "32px", background: "#22C55E", borderRadius: "50%", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: "14px", flexShrink: 0 }}>
                                            {item.id}
                                        </div>
                                        <div>
                                            <h3 style={{ fontSize: "16px", fontWeight: 700, color: "#1E293B", marginBottom: "4px" }}>{item.title}</h3>
                                            <p style={{ fontSize: "14px", fontWeight: 500, color: "#64748B", lineHeight: 1.5 }}>{item.desc}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </section>

                {/* ===== SYSTEM COMPATIBILITY ===== */}
                <section style={{ padding: "60px 40px", background: "#fff" }}>
                    <div style={{ maxWidth: "1000px", margin: "0 auto", textAlign: "center" }}>
                        <h2 style={{ fontSize: "20px", fontWeight: 800, color: "#111827", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: "40px", fontFamily: "'Outfit', sans-serif" }}>System Compatibility</h2>

                        <div style={{ background: "#F0FDF4", borderRadius: "24px", padding: "40px", textAlign: "center" }}>
                            <p style={{ fontSize: "14px", fontWeight: 600, color: "#1E293B", marginBottom: "32px" }}>Compatible with leading ERP and POS systems:</p>
                            <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "center", gap: "12px" }}>
                                {[
                                    "Tally Prime", "Tally ERP-9", "Busy", "Marg", "Zoho", "Wings", "Other ERP/POS Systems"
                                ].map((erp) => (
                                    <div key={erp} style={{ background: "#fff", padding: "8px 20px", borderRadius: "30px", fontSize: "13px", fontWeight: 600, color: "#065F46", border: "1px solid rgba(34,197,94,0.1)", boxShadow: "0 2px 8px rgba(0,0,0,0.04)" }}>
                                        {erp}
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </section>

                {/* ===== REQUEST DEMO CTA ===== */}
                <section style={{ padding: "60px 40px", background: "#fff", textAlign: "center" }}>
                    <div style={{ maxWidth: "1000px", margin: "0 auto" }}>
                        <button
                            onClick={() => window.open('https://wa.me/919876543210', '_blank')}
                            style={{
                                background: "#22C55E",
                                color: "#fff",
                                border: "none",
                                padding: "16px 48px",
                                borderRadius: "12px",
                                fontSize: "18px",
                                fontWeight: 700,
                                cursor: "pointer",
                                marginBottom: "24px",
                                fontFamily: "'Outfit', sans-serif",
                                boxShadow: "0 10px 20px rgba(34,197,94,0.2)",
                                transition: "transform 0.2s"
                            }}
                            onMouseOver={(e) => e.currentTarget.style.transform = "scale(1.02)"}
                            onMouseOut={(e) => e.currentTarget.style.transform = "scale(1)"}
                        >
                            Request Demo
                        </button>
                        <p style={{ fontSize: "16px", color: "#64748B", fontWeight: 500 }}>Modernize your business communications today</p>
                    </div>
                </section>

                {/* ===== GOOGLE SHEET INTEGRATION ===== */}
                <section style={{ padding: "80px 40px", background: "#FFF5F5" }}>
                    <div style={{ maxWidth: "1100px", margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "60px", alignItems: "center" }}>
                        <div style={{ position: "relative" }}>
                            <img
                                src="/google_sheet_integration.png"
                                alt="Google Sheet Integration"
                                style={{ width: "100%", borderRadius: "20px", boxShadow: "0 20px 40px rgba(0,0,0,0.05)" }}
                            />
                        </div>
                        <div>
                            <h2 style={{ fontSize: "28px", fontWeight: 800, color: "#334155", marginBottom: "16px", textTransform: "uppercase", fontFamily: "'Outfit', sans-serif" }}>
                                WHATSAPP MESSAGING + GOOGLE SHEET
                            </h2>
                            <p style={{ fontSize: "18px", color: "#64748B", fontWeight: 500, fontStyle: "italic", marginBottom: "32px" }}>
                                Get business whatsapp marketing to new heights.
                            </p>
                            <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
                                {[
                                    "Enhance your team performance 10x times",
                                    "Sync googlesheet data to set messaging campaigns and triggers",
                                    "Send whatsapp to unsaved numbers in your device"
                                ].map((item, i) => (
                                    <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: "12px" }}>
                                        <div style={{ color: "#22C55E", marginTop: "2px" }}>
                                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12" /></svg>
                                        </div>
                                        <p style={{ fontSize: "15px", fontWeight: 600, color: "#475569" }}>{item}</p>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </section>

                {/* ===== TALLY INTEGRATION ===== */}
                <section style={{ padding: "80px 40px", background: "#FFF5F5" }}>
                    <div style={{ maxWidth: "1100px", margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 1.2fr", gap: "60px", alignItems: "center" }}>
                        <div>
                            <h2 style={{ fontSize: "28px", fontWeight: 800, color: "#334155", marginBottom: "16px", textTransform: "uppercase", fontFamily: "'Outfit', sans-serif" }}>
                                TRANSFORM YOUR TALLY PRIME
                            </h2>
                            <p style={{ fontSize: "18px", color: "#64748B", fontWeight: 500, fontStyle: "italic", marginBottom: "32px" }}>
                                Free unlimited Tally to WhatsApp TDL
                            </p>
                            <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
                                {[
                                    "Send bills, Vouchers & Reports on Customer's Whatsapp from Tally",
                                    "Experience AI smart most advanced payment reminder tool",
                                    "Automate business process like sales & purchase order"
                                ].map((item, i) => (
                                    <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: "12px" }}>
                                        <div style={{ color: "#22C55E", marginTop: "2px" }}>
                                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12" /></svg>
                                        </div>
                                        <p style={{ fontSize: "15px", fontWeight: 600, color: "#475569" }}>{item}</p>
                                    </div>
                                ))}
                            </div>
                        </div>
                        <div style={{ position: "relative" }}>
                            <img
                                src="/tally_prime_v2_illustration_1774527172817.png"
                                alt="Tally Integration"
                                style={{ width: "100%", borderRadius: "20px", boxShadow: "0 20px 40px rgba(0,0,0,0.05)" }}
                            />
                        </div>
                    </div>
                </section>

                {/* ===== GOOGLE RCS SECTION ===== */}
                <section style={{ padding: "80px 40px", background: "#F0FDFA" }}>
                    <div style={{ maxWidth: "1100px", margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 1.2fr", gap: "60px", alignItems: "center" }}>
                        <div style={{ position: "relative" }}>
                            <img
                                src="/google_rcs_illustration.png"
                                alt="Google RCS Promotions"
                                style={{ width: "100%", borderRadius: "20px", boxShadow: "0 20px 40px rgba(0,0,0,0.05)" }}
                            />
                        </div>
                        <div>
                            <h2 style={{ fontSize: "28px", fontWeight: 800, color: "#334155", marginBottom: "16px", textTransform: "uppercase", fontFamily: "'Outfit', sans-serif" }}>
                                EXPLORE GOOGLE RCS - (BULK PROMOTIONS)
                            </h2>
                            <p style={{ fontSize: "18px", color: "#64748B", fontWeight: 500, fontStyle: "italic", marginBottom: "32px" }}>
                                Ideal promotional tool for small and large businesses.
                            </p>
                            <div style={{ display: "flex", flexDirection: "column", gap: "16px", marginBottom: "32px" }}>
                                {[
                                    "Look and feel similar to WhatsApp.",
                                    "80% cheaper than WhatsApp.",
                                    "No number blocking.",
                                    "Customer engagement through CTA buttons.",
                                    "Send text, image, and video in campaigns.",
                                    "Free access to panel and API."
                                ].map((item, i) => (
                                    <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: "12px" }}>
                                        <div style={{ color: "#22C55E", marginTop: "2px" }}>
                                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12" /></svg>
                                        </div>
                                        <p style={{ fontSize: "15px", fontWeight: 600, color: "#475569" }}>{item}</p>
                                    </div>
                                ))}
                            </div>
                            <button
                                onClick={() => router.push('/register')}
                                style={{
                                    background: "#0891B2",
                                    color: "#fff",
                                    border: "none",
                                    borderRadius: "8px",
                                    padding: "12px 32px",
                                    fontWeight: 700,
                                    fontSize: "15px",
                                    cursor: "pointer",
                                    boxShadow: "0 10px 20px rgba(8,145,178,0.2)"
                                }}
                            >Start now</button>
                        </div>
                    </div>
                </section>

                {/* ===== OUR SATISFIED CUSTOMERS ===== */}
                <section style={{ padding: "80px 40px", background: "#f8fafc" }}>
                    <div style={{ maxWidth: "1250px", margin: "0 auto", textAlign: "center" }}>
                        <h2 style={{ fontSize: "clamp(24px,4vw,36px)", fontWeight: 800, color: "#1E293B", marginBottom: "48px", textTransform: "uppercase", letterSpacing: "-0.5px" }}>Our Satisfied Customers</h2>

                        <div style={{
                            display: "grid",
                            gridTemplateColumns: "repeat(5, 1fr)",
                            gap: "20px",
                            maxWidth: "1100px",
                            margin: "0 auto"
                        }}>
                            {[
                                { src: "/logos/talaro.jpg", alt: "Talaro" },
                                { src: "/logos/market_brand.jpg", alt: "MarketBrand" },
                                { src: "/logos/jmj_book_store.jpg", alt: "JMJ Book Store" },
                                { src: "/logos/mandapam.png", alt: "Mandapam" },
                                { src: "/logos/safe_t_net.png", alt: "Safe T Net" }
                            ].map((logo, i) => (
                                <div key={i} style={{
                                    background: "#fff",
                                    padding: "20px",
                                    borderRadius: "16px",
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    boxShadow: "0 4px 12px rgba(0,0,0,0.03)",
                                    height: "140px",
                                    border: "1px solid #f1f5f9"
                                }}>
                                    <img src={logo.src} alt={logo.alt} style={{ maxWidth: "100%", maxHeight: "100%", objectFit: "contain" }} />
                                </div>
                            ))}
                        </div>
                    </div>
                </section>


                {/* ===== WHAT DO YOU WANT TO DO ===== */}
                <section style={{ padding: "80px 40px", background: "#FFFBF5" }}>
                    <div style={{ maxWidth: "1100px", margin: "0 auto", textAlign: "center" }}>
                        <h2 style={{ fontSize: "28px", fontWeight: 800, color: "#334155", marginBottom: "40px", textTransform: "uppercase", letterSpacing: "1px" }}>
                            What do you want to do on WhatsApp?
                        </h2>

                        <div style={{
                            display: "grid",
                            gridTemplateColumns: "repeat(3, 1fr)",
                            gap: "20px"
                        }}>
                            {[
                                { title: "TALLY / BUSY INTEGRATION", icon: "📜" },
                                { title: "GOOGLE SHEET INTEGRATION", icon: "📰" },
                                { title: "CRM INTEGRATION", icon: "👨‍💻" },
                                { title: "TRACK EMPLOYEE CHATS", icon: "🔔" },
                                { title: "AUTOMATE SALES / PURCHASE ORDER", icon: "🍂" },
                                { title: "BUSINESS PROMOTIONS", icon: "📐" },
                                { title: "CREATE TASK REMINDERS", icon: "⏱️" },
                                { title: "SCHEDULE WHATSAPP MESSAGES", icon: "🧑🤝🧑" },
                                { title: "EXTRACT CONTACTS FROM WHATSAPP GROUPS", icon: "📲" },
                            ].map((item, i) => (
                                <div key={i} className="feature-card" style={{
                                    padding: "30px 20px",
                                    background: "#DCFCE7",
                                    borderRadius: "12px",
                                    display: "flex",
                                    flexDirection: "column",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    gap: "16px",
                                    position: "relative",
                                    transition: "all 0.3s ease",
                                    cursor: "pointer",
                                    border: "1px solid rgba(0,0,0,0.05)"
                                }}>
                                    {/* Top-left square element from screenshot */}
                                    <div style={{
                                        position: "absolute",
                                        top: "12px",
                                        left: "12px",
                                        width: "12px",
                                        height: "12px",
                                        border: "2px solid #fff",
                                        borderRadius: "2px"
                                    }}></div>

                                    <div style={{ fontSize: "36px" }}>{item.icon}</div>
                                    <h3 style={{
                                        fontSize: "12px",
                                        fontWeight: 700,
                                        color: "#475569",
                                        textTransform: "uppercase",
                                        letterSpacing: "0.05em",
                                        lineHeight: 1.4,
                                        margin: 0
                                    }}>
                                        {item.title}
                                    </h3>
                                </div>
                            ))}
                        </div>
                    </div>
                </section>

                {/* ===== LET'S WORK TOGETHER FORM ===== */}
                <section style={{ padding: "100px 40px", background: "#fff" }}>
                    <div style={{ maxWidth: "800px", margin: "0 auto" }}>
                        <h2 style={{ fontSize: "clamp(24px,4vw,40px)", fontWeight: 800, color: "#334155", textAlign: "center", marginBottom: "60px", textTransform: "uppercase" }}>
                            Let&apos;s Work Together
                        </h2>

                        <form style={{ display: "flex", flexDirection: "column", gap: "24px" }}>
                            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px" }}>
                                <input type="text" placeholder="First Name" style={{ padding: "16px 20px", borderRadius: "10px", border: "1px solid #E2E8F0", fontSize: "15px", fontWeight: 500 }} />
                                <input type="text" placeholder="Last Name" style={{ padding: "16px 20px", borderRadius: "10px", border: "1px solid #E2E8F0", fontSize: "15px", fontWeight: 500 }} />
                            </div>

                            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px" }}>
                                <input type="email" placeholder="Email" style={{ padding: "16px 20px", borderRadius: "10px", border: "1px solid #E2E8F0", fontSize: "15px", fontWeight: 500 }} />
                                <input type="tel" placeholder="Phone" style={{ padding: "16px 20px", borderRadius: "10px", border: "1px solid #E2E8F0", fontSize: "15px", fontWeight: 500 }} />
                            </div>

                            <select style={{ padding: "16px 20px", borderRadius: "10px", border: "1px solid #E2E8F0", fontSize: "15px", fontWeight: 500, background: "#fff", color: "#64748B" }}>
                                <option>Select State</option>
                                <option>Maharashtra</option>
                                <option>Delhi</option>
                                <option>Karnataka</option>
                                <option>Gujarat</option>
                                <option>Other</option>
                            </select>

                            <textarea
                                rows={10}
                                defaultValue={`Hello,\nI am fascinated by the products & services of your company.\nI am specifically interested in:\n\nPlease contact me for further details on the above.\nRegards,\n\nEmail:- \nPhone:- `}
                                style={{
                                    padding: "20px",
                                    borderRadius: "10px",
                                    border: "1px solid #E2E8F0",
                                    fontSize: "15px",
                                    fontWeight: 700,
                                    fontFamily: "inherit",
                                    resize: "vertical",
                                    lineHeight: 1.6,
                                    color: "#334155"
                                }}
                            />

                            <label style={{ display: "flex", alignItems: "center", gap: "12px", fontSize: "14px", color: "#64748B", fontWeight: 600, cursor: "pointer" }}>
                                <input type="checkbox" style={{ width: "18px", height: "18px", cursor: "pointer", accentColor: "#22C55E" }} />
                                I authorize to send notifications via SMS / Email.
                            </label>

                            <div style={{ textAlign: "center", marginTop: "20px" }}>
                                <button
                                    type="submit"
                                    suppressHydrationWarning={true}
                                    style={{
                                        padding: "16px 60px",
                                        background: "#22C55E",
                                        color: "#fff",
                                        border: "none",
                                        borderRadius: "10px",
                                        fontSize: "16px",
                                        fontWeight: 800,
                                        cursor: "pointer",
                                        boxShadow: "0 10px 20px rgba(34,197,94,0.2)",
                                        transition: "transform 0.2s"
                                    }}
                                    onMouseOver={(e) => e.currentTarget.style.transform = "scale(1.02)"}
                                    onMouseOut={(e) => e.currentTarget.style.transform = "scale(1)"}
                                >
                                    Submit
                                </button>
                            </div>
                        </form>
                    </div>
                </section>

                {/* ===== WHAT OUR CLIENTS SAY ===== */}
                <section style={{ padding: "80px 40px", background: "#F7FEE7", overflow: "hidden" }}>
                    <div style={{ maxWidth: "1250px", margin: "0 auto", textAlign: "center", position: "relative" }}>
                        <div style={{ marginBottom: "40px" }}>
                            <div style={{ display: "inline-flex", alignItems: "center", gap: "12px", background: "rgba(34,197,94,0.1)", padding: "8px 20px", borderRadius: "100px", marginBottom: "16px" }}>
                                <Quote className="w-4 h-4 text-[#22C55E]" />
                                <span style={{ fontSize: "12px", fontWeight: 800, color: "#22C55E", textTransform: "uppercase", letterSpacing: "2px" }}>Testimonials</span>
                            </div>
                            <h2 style={{ fontSize: "clamp(24px,4vw,36px)", fontWeight: 800, color: "#334155", textTransform: "uppercase", letterSpacing: "1px" }}>
                                What Our Clients Say
                            </h2>
                        </div>

                        <div style={{ position: "relative", maxWidth: "750px", margin: "0 auto" }}>
                            {/* Navigation Buttons */}
                            <div style={{ position: "absolute", left: "-60px", right: "-60px", top: "50%", transform: "translateY(-50%)", display: "flex", justifyContent: "space-between", zIndex: 10, pointerEvents: "none" }}>
                                <button
                                    onClick={prevTestimonial}
                                    style={{
                                        width: "48px", height: "48px", borderRadius: "50%", background: "#fff",
                                        border: "none", cursor: "pointer", display: "flex",
                                        alignItems: "center", justifyContent: "center", boxShadow: "0 10px 25px rgba(0,0,0,0.08)",
                                        transition: "all 0.3s", pointerEvents: "auto"
                                    }}
                                    onMouseOver={(e) => { e.currentTarget.style.transform = "scale(1.1)"; e.currentTarget.style.background = "#22C55E"; e.currentTarget.style.color = "#fff" }}
                                    onMouseOut={(e) => { e.currentTarget.style.transform = "scale(1)"; e.currentTarget.style.background = "#fff"; e.currentTarget.style.color = "#334155" }}
                                >
                                    <ChevronLeft className="w-6 h-6" />
                                </button>

                                <button
                                    onClick={nextTestimonial}
                                    style={{
                                        width: "48px", height: "48px", borderRadius: "50%", background: "#fff",
                                        border: "none", cursor: "pointer", display: "flex",
                                        alignItems: "center", justifyContent: "center", boxShadow: "0 10px 25px rgba(0,0,0,0.08)",
                                        transition: "all 0.3s", pointerEvents: "auto"
                                    }}
                                    onMouseOver={(e) => { e.currentTarget.style.transform = "scale(1.1)"; e.currentTarget.style.background = "#22C55E"; e.currentTarget.style.color = "#fff" }}
                                    onMouseOut={(e) => { e.currentTarget.style.transform = "scale(1)"; e.currentTarget.style.background = "#fff"; e.currentTarget.style.color = "#334155" }}
                                >
                                    <ChevronRight className="w-6 h-6" />
                                </button>
                            </div>

                            {/* Carousel Content */}
                            <div style={{ overflow: "hidden", borderRadius: "32px", boxShadow: "0 40px 80px -20px rgba(34,197,94,0.12)", border: "1px solid rgba(255,255,255,0.8)" }}>
                                <div style={{
                                    display: "flex",
                                    transform: `translateX(-${testimonialIndex * 100}%)`,
                                    transition: "transform 0.8s cubic-bezier(0.16, 1, 0.3, 1)"
                                }}>
                                    {testimonials.map((client, i) => (
                                        <div key={i} style={{
                                            minWidth: "100%",
                                            background: "#fff",
                                            padding: "50px 40px",
                                            display: "flex",
                                            flexDirection: "column",
                                            alignItems: "center",
                                            textAlign: "center"
                                        }}>
                                            <div style={{ marginBottom: "32px", height: "80px", display: "flex", alignItems: "center", justifyContent: "center" }}>
                                                <img src={client.logo} alt={client.name} style={{ maxHeight: "60px", maxWidth: "180px", objectFit: "contain", filter: "drop-shadow(0 2px 4px rgba(0,0,0,0.03))" }} />
                                            </div>

                                            <p style={{
                                                fontSize: "clamp(16px, 1.8vw, 20px)",
                                                fontWeight: 700,
                                                color: "#475569",
                                                lineHeight: 1.5,
                                                marginBottom: "32px",
                                                fontStyle: "italic",
                                                maxWidth: "600px",
                                                fontFamily: "'Inter', sans-serif"
                                            }}>
                                                &ldquo;{client.text}&rdquo;
                                            </p>

                                            <div style={{ background: "#F1F5F9", padding: "10px 28px", borderRadius: "100px", border: "1px solid #E2E8F0" }}>
                                                <span style={{ fontSize: "13px", fontWeight: 800, color: "#334155", textTransform: "uppercase", letterSpacing: "1px" }}>{client.name}</span>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            {/* Indicators */}
                            <div style={{ display: "flex", justifyContent: "center", gap: "8px", marginTop: "32px" }}>
                                {testimonials.map((_, i) => (
                                    <button
                                        key={i}
                                        onClick={() => setTestimonialIndex(i)}
                                        style={{
                                            width: testimonialIndex === i ? "32px" : "8px",
                                            height: "8px",
                                            borderRadius: "8px",
                                            background: testimonialIndex === i ? "#22C55E" : "#CBD5E1",
                                            border: "none",
                                            cursor: "pointer",
                                            transition: "all 0.4s"
                                        }}
                                    />
                                ))}
                            </div>
                        </div>
                    </div>
                </section>


                <section style={{ padding: "60px 40px", background: "#fff" }}>

                    <div style={{ maxWidth: "1000px", margin: "0 auto", textAlign: "center" }}>
                        <h2 style={{ fontSize: "24px", fontWeight: 800, color: "#1E293B", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: "16px", fontFamily: "'Outfit', sans-serif" }}>
                            Powerful Marketing Use Cases
                        </h2>
                        <p style={{ fontSize: "16px", color: "#64748B", fontWeight: 500, marginBottom: "40px" }}>
                            Deliver real results across every customer touchpoint.
                        </p>
                        <div style={{ maxWidth: "800px", margin: "0 auto", borderRadius: "24px", overflow: "hidden", boxShadow: "0 20px 50px rgba(0,0,0,0.08)", border: "1px solid #f1f5f9" }}>
                            <img
                                src="/marketing_use_cases.png"
                                alt="Marketing Use Cases"
                                style={{ width: "100%", display: "block" }}
                            />
                        </div>
                    </div>
                </section>

                {/* ===== TPS - PCM SECTION ===== */}
                <section style={{ padding: "100px 40px", background: "#fff" }}>
                    <div style={{ maxWidth: "1200px", margin: "0 auto", textAlign: "center" }}>
                        <h2 style={{ fontSize: "clamp(32px,5vw,56px)", fontWeight: 800, color: "#1E293B", textTransform: "uppercase", marginBottom: "60px", letterSpacing: "-1px" }}>TPS - PCM</h2>

                        <div style={{ maxWidth: "800px", margin: "0 auto", textAlign: "left", display: "flex", flexDirection: "column", gap: "24px", marginBottom: "60px" }}>
                            {[
                                "Scan for Mobile connect",
                                "Any ERP or Billing software list",
                                "Get Mobile Print Solution",
                                "Directly Connected To"
                            ].map((step, i) => (
                                <div key={i} style={{ display: "flex", alignItems: "center", gap: "20px" }}>
                                    <div style={{ width: "32px", height: "32px", background: "#22C55E", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12" /></svg>
                                    </div>
                                    <span style={{ fontSize: "20px", fontWeight: 700, color: "#334155" }}>{step}</span>
                                </div>
                            ))}
                        </div>

                        {/* Connected To Logos */}
                        <div style={{ background: "#F0FDF4", padding: "40px", borderRadius: "32px", border: "1px solid #DCFCE7" }}>
                            <div style={{ display: "flex", justifyContent: "center", alignItems: "center", gap: "40px", flexWrap: "wrap", marginBottom: "40px" }}>
                                {["WhatsApp", "Facebook", "Instagram", "Google", "Twitter", "LinkedIn"].map(brand => (
                                    <span key={brand} style={{ fontSize: "16px", fontWeight: 800, color: "#16A34A", opacity: 0.7, textTransform: "uppercase" }}>{brand}</span>
                                ))}
                            </div>
                            <button
                                onClick={() => router.push('/register')}
                                suppressHydrationWarning={true}
                                style={{ height: "52px", padding: "0 40px", background: "#22C55E", color: "#fff", border: "none", borderRadius: "12px", fontWeight: 800, fontSize: "15px", cursor: "pointer", transition: "transform .2s" }}
                            >Join with Digital Bill</button>
                        </div>
                    </div>
                </section>

                {/* ===== MODERN BUSINESS & STORE ===== */}
                <div style={{ padding: "80px 40px", background: "#FEF2F2" }}>
                    <div style={{ maxWidth: "1000px", margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 1.2fr", gap: "50px", alignItems: "center" }}>
                        <div style={{ borderRadius: "24px", overflow: "hidden", boxShadow: "0 20px 40px rgba(0,0,0,0.08)" }}>
                            <img src="/google_rcs_illustration.png" alt="Online Store" style={{ width: "100%", height: "auto", display: "block" }} />
                        </div>
                        <div>
                            <h2 style={{ fontSize: "clamp(24px,3vw,36px)", fontWeight: 800, color: "#1E293B", lineHeight: 1.2, marginBottom: "16px" }}>Modern Business & <span style={{ color: "#22C55E" }}>Online Store</span></h2>
                            <p style={{ fontSize: "16px", fontWeight: 500, color: "#64748B", lineHeight: 1.6, marginBottom: "24px" }}>Streamline every step of your customer interaction from first contact to final delivery.</p>
                            <ul style={{ listStyle: "none", display: "flex", flexDirection: "column", gap: "12px" }}>
                                {["Automated order updates and alerts", "Flash sale alerts for better conversion", "Customer feedback collection instantly", "Direct product links for quick purchase"].map(i => (
                                    <li key={i} style={{ display: "flex", alignItems: "center", gap: "12px", fontSize: "14px", fontWeight: 600, color: "#475569" }}>
                                        <div style={{ width: "24px", height: "24px", borderRadius: "50%", background: "#DCFCE7", color: "#22C55E", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12" /></svg>
                                        </div>{i}
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </div>
                </div>

                {/* ===== ACCOUNTING & SMART INVOICE ===== */}
                <div style={{ padding: "80px 40px", background: "#FAF5FF" }}>
                    <div style={{ maxWidth: "1000px", margin: "0 auto", display: "grid", gridTemplateColumns: "1.2fr 1fr", gap: "50px", alignItems: "center" }}>
                        <div>
                            <h2 style={{ fontSize: "clamp(24px,3vw,36px)", fontWeight: 800, color: "#1E293B", lineHeight: 1.2, marginBottom: "16px" }}>Modern Billing and <span style={{ color: "#7C3AED" }}>Smart Invoice</span></h2>
                            <p style={{ fontSize: "16px", fontWeight: 500, color: "#64748B", lineHeight: 1.6, marginBottom: "24px" }}>Generate and send digital invoices instantly after every transaction.</p>
                            <ul style={{ listStyle: "none", display: "flex", flexDirection: "column", gap: "12px" }}>
                                {["GST & Non-GST invoice support", "Thermal & A4 print options", "Payment reminder alerts via WhatsApp", "Daily sales analytics for better business"].map(i => (
                                    <li key={i} style={{ display: "flex", alignItems: "center", gap: "12px", fontSize: "14px", fontWeight: 600, color: "#475569" }}>
                                        <div style={{ width: "24px", height: "24px", borderRadius: "50%", background: "#EDE9FE", color: "#7C3AED", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12" /></svg>
                                        </div>{i}
                                    </li>
                                ))}
                            </ul>
                        </div>
                        <div style={{ borderRadius: "24px", overflow: "hidden", boxShadow: "0 20px 40px rgba(0,0,0,0.08)" }}>
                            <img src="/google_sheet_integration.png" alt="Digital Billing" style={{ width: "100%", height: "auto", display: "block" }} />
                        </div>
                    </div>
                </div>

                {/* ===== CONTROL YOUR BUSINESS ===== */}
                <div style={{ padding: "80px 40px", background: "#ECFEFF" }}>
                    <div style={{ maxWidth: "1000px", margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 1.2fr", gap: "50px", alignItems: "center" }}>
                        <div style={{ borderRadius: "24px", overflow: "hidden", boxShadow: "0 20px 40px rgba(0,0,0,0.08)" }}>
                            <img src="/integration_mockup.png" alt="Business Control" style={{ width: "100%", height: "auto", display: "block" }} />
                        </div>
                        <div>
                            <h2 style={{ fontSize: "clamp(24px,3vw,36px)", fontWeight: 800, color: "#1E293B", lineHeight: 1.2, marginBottom: "16px" }}>Ready to control <span style={{ color: "#0891B2" }}>your Business?</span></h2>
                            <p style={{ fontSize: "16px", fontWeight: 500, color: "#64748B", lineHeight: 1.6, marginBottom: "24px" }}>Get up and running in minutes. Designed for rapid deployment and massive scalability.</p>
                            <ul style={{ listStyle: "none", display: "flex", flexDirection: "column", gap: "12px", marginBottom: "32px" }}>
                                {["24/7 automated chatbot for support", "Multi-admin collaboration securely", "Global message reach with no limits", "Zero-code API integration in minutes"].map(i => (
                                    <li key={i} style={{ display: "flex", alignItems: "center", gap: "12px", fontSize: "14px", fontWeight: 600, color: "#475569" }}>
                                        <div style={{ width: "24px", height: "24px", borderRadius: "50%", background: "#E0F2FE", color: "#0891B2", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12" /></svg>
                                        </div>{i}
                                    </li>
                                ))}
                            </ul>
                            <button
                                onClick={() => router.push('/register')}
                                suppressHydrationWarning={true}
                                className="btn" style={{ height: "48px", padding: "0 32px", borderRadius: "10px", border: "none", fontWeight: 700, fontSize: "14px", background: "#0891B2", color: "#fff", cursor: "pointer", transition: "all .2s" }}
                            >Trial Now</button>
                        </div>
                    </div>
                </div>

                {/* ===== SEAMLESS INTEGRATIONS ===== */}
                <section style={{ padding: "80px 40px", background: "#fff" }}>
                    <div style={{ maxWidth: "1000px", margin: "0 auto", textAlign: "center" }}>
                        <h2 style={{ fontSize: "clamp(24px,3.5vw,44px)", fontWeight: 800, color: "#1E293B", lineHeight: 1.1, marginBottom: "20px" }}>
                            SEAMLESS <span style={{ color: "#22C55E" }}>INTEGRATIONS</span>
                        </h2>
                        <p style={{ fontSize: "16px", fontWeight: 600, color: "#64748B", maxWidth: "700px", margin: "0 auto 40px", lineHeight: 1.6 }}>
                            Connect your favorite tools directly to WhatsApp. Our platform bridges the gap between your core business software and instant customer communication.
                        </p>

                        <div style={{
                            background: "#F8FAFC", borderRadius: "32px", padding: "40px",
                            border: "1px solid #E2E8F0", boxShadow: "0 20px 40px rgba(0,0,0,0.05)",
                            overflow: "hidden"
                        }}>
                            <img
                                src="/integration_mockup.png"
                                alt="Integration Interface"
                                style={{
                                    width: "100%", height: "auto", borderRadius: "20px",
                                    boxShadow: "0 10px 30px rgba(0,0,0,0.1)"
                                }}
                            />
                        </div>

                        <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: "24px", marginTop: "60px" }}>
                            {[
                                { title: "Tally Prime", desc: "Sync your accounting data instantly" },
                                { title: "Busy ERP", desc: "Automate invoices and reports" },
                                { title: "Google Sheets", desc: "Manage contacts and broadcasts" },
                                { title: "CRM / Custom", desc: "Flexible API for any platform" }
                            ].map((integ, i) => (
                                <div key={i} style={{ padding: "24px", background: "#fff", borderRadius: "20px", border: "1px solid #F1F5F9", textAlign: "left" }}>
                                    <h4 style={{ fontSize: "16px", fontWeight: 800, color: "#1E293B", marginBottom: "8px" }}>{integ.title}</h4>
                                    <p style={{ fontSize: "13px", fontWeight: 600, color: "#64748B" }}>{integ.desc}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                </section>


                {/* ===== WE ASSIST YOU (USE CASES) ===== */}
                <section style={{ padding: "80px 40px", background: "#F0FDF4" }}>
                    <div style={{ maxWidth: "1000px", margin: "0 auto", textAlign: "center" }}>
                        <h2 style={{ fontSize: "clamp(20px,4vw,36px)", fontWeight: 800, color: "#1E293B", lineHeight: 1.2, marginBottom: "40px" }}>
                            WE ASSIST YOU <br /><span style={{ color: "#22C55E" }}>TO DO ON WHATSAPP</span>
                        </h2>
                        <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: "20px" }}>
                            {[
                                { title: "Appointment Reminders", icon: <circle cx="12" cy="12" r="10" /> },
                                { title: "Shipping Updates", icon: <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" /> },
                                { title: "Order Confirmations", icon: <polyline points="20 6 9 17 4 12" /> },
                                { title: "Loyalty Programs", icon: <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" /> },
                                { title: "Personalized Offers", icon: <path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z" /> },
                                { title: "Customer Feedback", icon: <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" /> },
                            ].map((u, i) => (
                                <div key={i} style={{ padding: "30px", background: "#fff", borderRadius: "24px", textAlign: "center", boxShadow: "0 8px 24px rgba(0,0,0,0.03)" }}>
                                    <div style={{ width: "40px", height: "40px", background: "#DCFCE7", color: "#22C55E", borderRadius: "12px", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px" }}>
                                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">{u.icon}</svg>
                                    </div>
                                    <h3 style={{ fontSize: "15px", fontWeight: 700, color: "#1E293B" }}>{u.title}</h3>
                                </div>
                            ))}
                        </div>
                    </div>
                </section>
                {/* ===== PORTFOLIO ===== */}
                <section style={{ padding: "80px 40px", background: "#fff" }}>
                    <div style={{ maxWidth: "1000px", margin: "0 auto", textAlign: "center" }}>
                        <h2 style={{ fontSize: "clamp(24px,3.5vw,32px)", fontWeight: 800, color: "#1E293B", marginBottom: "40px", textTransform: "uppercase" }}>Check our Portfolio</h2>
                        <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: "20px" }}>
                            {[1, 2, 3, 4, 5, 6].map(i => (
                                <div key={i} style={{ aspectRatio: "16/10", background: "#f1f5f9", borderRadius: "20px", overflow: "hidden", border: "1px solid #e2e8f0", position: "relative" }}>
                                    <div style={{ width: "100%", height: "100%", background: "linear-gradient(135deg, #fff 0%, #f1f5f9 100%)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                                        <span style={{ fontWeight: 700, color: "#cbd5e1", fontSize: "11px", textTransform: "uppercase" }}>Dashboard Screen {i}</span>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </section>



                {/* ===== FAQ ===== */}
                <section style={{ padding: "80px 40px", background: "#fff" }}>
                    <div style={{ maxWidth: "700px", margin: "0 auto" }}>
                        <h2 style={{ fontSize: "clamp(20px,3.5vw,28px)", fontWeight: 800, color: "#1E293B", textAlign: "center", marginBottom: "40px", textTransform: "uppercase" }}>Frequently Asked Questions</h2>
                        <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                            {[
                                { q: "How fast is the setup process?", a: "Setup is incredibly fast. Most users are up and running in under 5 minutes with our zero-code interface." },
                                { q: "Is my business data secure?", a: "We use enterprise-grade 256-bit encryption for all your data and messages, ensuring complete privacy." },
                                { q: "Can I send messages internationally?", a: "Yes! Our platform supports global messaging with no country-specific restrictions." },
                                { q: "What printers are supported for billing?", a: "We support nearly all Bluetooth and Wi-Fi thermal printers, including ESC/POS standard devices." }
                            ].map((item, i) => (
                                <div key={i} style={{ border: "1px solid #e2e8f0", borderRadius: "12px", overflow: "hidden" }}>
                                    <div style={{ padding: "16px 20px", background: "#f8fafc", fontWeight: 700, color: "#1E293B", cursor: "pointer", display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: "14px" }}>
                                        {item.q}
                                        <span style={{ color: "#22C55E" }}>+</span>
                                    </div>
                                    <div style={{ padding: "16px 20px", background: "#fff", color: "#64748B", fontWeight: 500, fontSize: "13px", lineHeight: 1.5 }}>
                                        {item.a}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </section>

                {/* ===== FOOTER ===== */}
                <footer style={{ background: "#0F172A", color: "#94A3B8", padding: "80px 40px 40px" }}>
                    <div style={{ maxWidth: "1000px", margin: "0 auto", display: "grid", gridTemplateColumns: "1.5fr 1fr 1fr 1.2fr", gap: "40px", marginBottom: "60px" }}>
                        <div>
                            <div style={{ marginBottom: "20px" }}>
                                <Logo light />
                            </div>
                            <p style={{ fontSize: "14px", fontWeight: 500, lineHeight: 1.5, maxWidth: "280px" }}>The ultimate automation platform for modern businesses looking to scale through WhatsApp API.</p>
                        </div>
                        <div>
                            <h4 style={{ color: "#fff", fontWeight: 700, marginBottom: "20px", textTransform: "uppercase", fontSize: "13px" }}>Platform</h4>
                            <ul style={{ listStyle: "none", display: "flex", flexDirection: "column", gap: "10px", fontSize: "13px", fontWeight: 500 }}>
                                <li><a href="#" style={{ color: "inherit", textDecoration: "none" }}>Solutions</a></li>
                                <li><a href="#" style={{ color: "inherit", textDecoration: "none" }}>Marketing</a></li>
                                <li><a href="#" style={{ color: "inherit", textDecoration: "none" }}>Automation</a></li>
                                <li><a href="#" style={{ color: "inherit", textDecoration: "none" }}>Pricing</a></li>
                            </ul>
                        </div>
                        <div>
                            <h4 style={{ color: "#fff", fontWeight: 700, marginBottom: "20px", textTransform: "uppercase", fontSize: "13px" }}>Resources</h4>
                            <ul style={{ listStyle: "none", display: "flex", flexDirection: "column", gap: "10px", fontSize: "13px", fontWeight: 500 }}>
                                <li><a href="#" style={{ color: "inherit", textDecoration: "none" }}>Documentation</a></li>
                                <li><a href="#" style={{ color: "inherit", textDecoration: "none" }}>API Reference</a></li>
                                <li><a href="#" style={{ color: "inherit", textDecoration: "none" }}>Support</a></li>
                                <li><a href="#" style={{ color: "inherit", textDecoration: "none" }}>Privacy</a></li>
                            </ul>
                        </div>
                        <div>
                            <h4 style={{ color: "#fff", fontWeight: 700, marginBottom: "20px", textTransform: "uppercase", fontSize: "13px" }}>Contact Us</h4>
                            <div style={{ display: "flex", flexDirection: "column", gap: "12px", fontSize: "13px", fontWeight: 500 }}>
                                <p>Email: hello@whatsappapi.com</p>
                                <p>Phone: +91 98765 43210</p>
                                <p>Location: Mumbai, India</p>
                            </div>
                        </div>
                    </div>
                    <div style={{ maxWidth: "1000px", margin: "0 auto", borderTop: "1px solid #1E293B", textAlign: "center", paddingTop: "32px" }}>
                        <p style={{ fontSize: "12px", fontWeight: 500 }}>&copy; 2026 WHATSAPP BUSINESS API SOLUTION. All Rights Reserved.</p>
                    </div>
                </footer>
            </div>
        </>
    )
}