"use client"

import React, { useState } from "react"
import { LayoutGrid, Users, Wallet, Crown, Zap, List, Grid, TrendingDown } from "lucide-react"
import { cn } from "@/lib/utils"
import { Plan, PlanCard } from "@/components/plans/PlanCard"
import { PlanTable } from "@/components/plans/PlanTable"

const allPlans: Plan[] = [
    { id:"starter",   name:"STARTER",    price:"5,000",  type:"One-time payment", credits:"25,000 Credits",  rate:"0.20 paise per message", wallet:"₹0", validity:"365 days", support:"24/7 Support", popular:false, category:"reseller" },
    { id:"business",  name:"BUSINESS",   price:"10,000", type:"One-time payment", credits:"100,000 Credits", rate:"0.10 paise per message", wallet:"₹0", validity:"365 days", support:"24/7 Support", popular:true,  category:"reseller" },
    { id:"enterprise",name:"ENTERPRISE", price:"50,000", type:"One-time payment", credits:"600,000 Credits", rate:"0.08 paise per message", wallet:"₹0", validity:"365 days", support:"24/7 Support", popular:false, category:"reseller" },
    { id:"demo",    name:"DEMO",   price:"0",      type:"One-time payment", credits:"30 Credits",      rate:"0 paise per message",    wallet:"₹0", validity:"3 days",   support:"24/7 Support", popular:false, isDemo:true, icon:Zap, category:"user" },
    { id:"map-9a",  name:"MAP 9A", price:"500",    type:"One-time payment", credits:"1,000 Credits",   rate:"0.5 paise per message",  wallet:"₹0", validity:"30 days",  support:"24/7 Support", popular:false, category:"user" },
    { id:"map-9b",  name:"MAP 9B", price:"2,000",  type:"One-time payment", credits:"5,000 Credits",   rate:"0.4 paise per message",  wallet:"₹0", validity:"180 days", support:"24/7 Support", popular:false, category:"user" },
    { id:"map-9d",  name:"MAP 9D", price:"6,000",  type:"One-time payment", credits:"25,000 Credits",  rate:"0.24 paise per message", wallet:"₹0", validity:"360 days", support:"24/7 Support", popular:false, category:"user" },
    { id:"map-9c",  name:"MAP 9C", price:"3,000",  type:"One-time payment", credits:"10,000 Credits",  rate:"0.3 paise per message",  wallet:"₹0", validity:"360 days", support:"24/7 Support", popular:false, category:"user" },
    { id:"map-9e",  name:"MAP 9E", price:"11,000", type:"One-time payment", credits:"50,000 Credits",  rate:"0.22 paise per message", wallet:"₹0", validity:"360 days", support:"24/7 Support", popular:false, category:"user" },
]

type PlanType = "all" | "reseller" | "user"

const overviewCards = [
    { id:"all",      label:"Total Plans",    icon:LayoutGrid,    bg:"#EFF6FF", border:"#BFDBFE", text:"#1D4ED8", iconBg:"#DBEAFE" },
    { id:"reseller", label:"Reseller Plans", icon:Crown,         bg:"#F5F3FF", border:"#DDD6FE", text:"#6D28D9", iconBg:"#EDE9FE" },
    { id:"user",     label:"User Plans",     icon:Users,         bg:"#F0FDF4", border:"#BBF7D0", text:"#15803D", iconBg:"#DCFCE7" },
    { id:"price",    label:"Avg Price",      icon:TrendingDown,  bg:"#FFFBEB", border:"#FDE68A", text:"#B45309", iconBg:"#FEF3C7", value:"₹22,214", noFilter:true },
]

export default function PlansPage() {
    const [viewMode, setViewMode]       = useState<"card"|"table">("card")
    const [activePlanType, setActivePlanType] = useState<PlanType>("all")

    const filtered = allPlans.filter(p => activePlanType === "all" || p.category === activePlanType)

    const countMap: Record<string,string> = {
        all:    allPlans.length.toString(),
        reseller: allPlans.filter(p=>p.category==="reseller").length.toString(),
        user:   allPlans.filter(p=>p.category==="user").length.toString(),
        price:  "₹22,214",
    }

    return (
        <div className="max-w-[1400px] mx-auto space-y-8 p-8 pt-6 page-enter">

            {/* ── Header ── */}
            <div className="page-header">
                <div className="page-header-icon">
                    <Wallet className="h-5 w-5" />
                </div>
                <div>
                    <h2 className="text-2xl font-bold text-slate-900">Pricing Plans</h2>
                    <p className="text-sm text-slate-500 mt-0.5">Choose the perfect plan for your messaging needs</p>
                </div>
            </div>

            {/* ── Overview filter cards — soft pastel ── */}
            <div className="space-y-3">
                <p className="label">Plans Overview</p>
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 stagger">
                    {overviewCards.map((c) => {
                        const Icon    = c.icon
                        const isActive = activePlanType === c.id
                        return (
                            <div
                                key={c.id}
                                onClick={() => !c.noFilter && setActivePlanType(c.id as PlanType)}
                                className={cn(
                                    "rounded-2xl p-5 border flex items-start justify-between gap-3 transition-all duration-200",
                                    !c.noFilter && "cursor-pointer hover:-translate-y-0.5 hover:shadow-lg",
                                    isActive && !c.noFilter && "ring-2 ring-offset-2"
                                )}
                                style={{
                                    background:  c.bg,
                                    borderColor: isActive && !c.noFilter ? c.text : c.border,
                                    ringColor:   c.text,
                                    boxShadow:   isActive && !c.noFilter
                                        ? `0 0 0 2px ${c.text}40, 0 4px 16px rgba(0,0,0,.08)`
                                        : undefined,
                                }}
                            >
                                <div>
                                    <p className="text-xs font-semibold uppercase tracking-wide mb-2"
                                       style={{ color:c.text, opacity:.65 }}>{c.label}</p>
                                    <p className="text-2xl font-bold tracking-tight"
                                       style={{ color:c.text }}>{countMap[c.id]}</p>
                                    {isActive && !c.noFilter && (
                                        <p className="text-[10px] mt-1.5 font-semibold uppercase tracking-wider"
                                           style={{ color:c.text, opacity:.55 }}>Filtered ✓</p>
                                    )}
                                </div>
                                <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                                     style={{ background:c.iconBg }}>
                                    <Icon className="h-5 w-5" style={{ color:c.text }} />
                                </div>
                            </div>
                        )
                    })}
                </div>
            </div>

            {/* ── Plans list ── */}
            <div className="space-y-5">
                {/* List header + view toggle */}
                <div className="flex items-center justify-between flex-wrap gap-3">
                    <div className="flex items-center gap-2.5">
                        <div className="page-header-icon w-8 h-8">
                            <LayoutGrid className="h-4 w-4" />
                        </div>
                        <h3 className="text-sm font-semibold text-slate-800 capitalize">
                            {activePlanType === "all" ? "All Plans" : `${activePlanType} Plans`}
                            <span className="ml-2 text-xs text-slate-400 font-normal bg-slate-100 px-2 py-0.5 rounded-full">
                                {filtered.length} found
                            </span>
                        </h3>
                    </div>
                    <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
                        {(["card","table"] as const).map((v) => (
                            <button
                                key={v}
                                onClick={() => setViewMode(v)}
                                className={cn(
                                    "flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all",
                                    viewMode === v
                                        ? "bg-white text-slate-800 shadow-sm"
                                        : "text-slate-500 hover:text-slate-700"
                                )}
                            >
                                {v === "card"
                                    ? <><Grid className="h-3.5 w-3.5" />Card View</>
                                    : <><List className="h-3.5 w-3.5" />Table View</>
                                }
                            </button>
                        ))}
                    </div>
                </div>

                {viewMode === "card" ? (
                    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 stagger">
                        {filtered.map((plan) => (
                            <PlanCard key={plan.id} plan={plan} />
                        ))}
                    </div>
                ) : (
                    <PlanTable plans={filtered} />
                )}

                {filtered.length === 0 && (
                    <div className="text-center py-20 bg-white rounded-2xl border-2 border-dashed border-slate-200">
                        <p className="text-sm text-slate-400 font-medium">No plans found for this category.</p>
                    </div>
                )}
            </div>
        </div>
    )
}
