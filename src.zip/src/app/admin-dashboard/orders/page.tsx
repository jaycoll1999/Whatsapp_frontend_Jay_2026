"use client"

import { useState } from "react"
import { 
    ShoppingCart, 
    CheckCircle2, 
    Zap, 
    Clock, 
    ChevronRight, 
    Filter,
    Search,
    Download,
    Calendar,
    Box,
    UserCheck,
    CreditCard
} from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { useEffect, useCallback } from "react"
import creditService from "@/services/creditService"
import { Loader2 } from "lucide-react"

// Real orders will be fetched from API
interface Order {
    id: string;
    txnid: string;
    plan_name: string;
    credits: number;
    amount: number;
    status: string;
    razorpay_order_id?: string;
    razorpay_payment_id?: string;
    allocated_to_user_id?: string;
    is_allocated: string;
    created_at: string;
    updated_at: string;
}



export default function AdminOrdersPage() {
    const [searchQuery, setSearchQuery] = useState("")
    const [orders, setOrders] = useState<Order[]>([])
    const [isLoading, setIsLoading] = useState(true)

    const fetchOrders = useCallback(async () => {
        setIsLoading(true)
        try {
            const token = localStorage.getItem('token') || "mock-admin-token-6631"
            const data = await creditService.getMyOrders(token)
            setOrders(data)
        } catch (error) {
            console.error("Failed to fetch orders:", error)
        } finally {
            setIsLoading(false)
        }
    }, [])

    useEffect(() => {
        fetchOrders()
    }, [fetchOrders])

    const filteredOrders = orders.filter(order => 
        order.txnid.toLowerCase().includes(searchQuery.toLowerCase()) ||
        order.plan_name.toLowerCase().includes(searchQuery.toLowerCase())
    )

    const formatDate = (dateStr: string) => {
        try {
            const date = new Date(dateStr)
            return date.toLocaleString('en-IN', {
                day: '2-digit',
                month: 'short',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
                hour12: true
            })
        } catch (e) {
            return dateStr
        }
    }

    return (
        <div className="space-y-8 animate-in fade-in duration-700">
            {/* Header Section */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                    <div className="p-3 bg-emerald-50 rounded-2xl text-emerald-600 border border-emerald-100 shadow-sm">
                        <ShoppingCart className="w-8 h-8" />
                    </div>
                    <div>
                        <h1 className="text-3xl font-black tracking-tight text-slate-900">Order History</h1>
                        <p className="text-slate-500 font-bold text-xs uppercase tracking-widest mt-0.5">Track all purchases and allocate credits to your business users</p>
                    </div>
                </div>
                <div className="flex items-center gap-3">
                    <Button variant="outline" className="rounded-xl font-bold gap-2 border-slate-200">
                        <Download className="w-4 h-4" />
                        Export
                    </Button>
                    <Button className="bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold gap-2 shadow-lg shadow-emerald-600/20">
                        <Calendar className="w-4 h-4" />
                        Date Range
                    </Button>
                </div>
            </div>

            {/* Main Content Area */}
            <Card className="border-none shadow-xl shadow-slate-200/50 rounded-[2.5rem] overflow-hidden">
                <CardContent className="p-0">
                    <div className="p-8 border-b border-slate-100 bg-slate-50/50 flex flex-col md:flex-row md:items-center justify-between gap-6">
                        <div className="flex items-center gap-4">
                            <div className="p-2 bg-white rounded-lg border border-slate-200 shadow-sm text-emerald-600">
                                <Box className="w-5 h-5" />
                            </div>
                            <div>
                                <h2 className="text-lg font-black text-slate-900 leading-tight">Your Orders <span className="ml-2 text-slate-400 font-bold text-sm bg-slate-100 px-2 py-0.5 rounded-full">{filteredOrders.length}</span></h2>
                                <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">Paid orders can be allocated to a business user</p>
                            </div>
                        </div>

                        <div className="relative w-full md:w-80">
                            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                            <Input 
                                placeholder="Search by Order ID or Plan..." 
                                className="pl-10 h-10 bg-white border-slate-200 rounded-xl focus:ring-emerald-500 font-medium"
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                            />
                        </div>
                    </div>

                    <div className="p-8 space-y-6 bg-white">
                        {isLoading ? (
                            <div className="flex flex-col items-center justify-center py-20 space-y-4">
                                <Loader2 className="h-10 w-10 animate-spin text-emerald-600" />
                                <p className="text-slate-400 font-bold uppercase tracking-widest text-xs">Loading orders...</p>
                            </div>
                        ) : filteredOrders.length === 0 ? (
                            <div className="flex flex-col items-center justify-center py-20 space-y-4">
                                <div className="p-4 bg-slate-50 rounded-full">
                                    <ShoppingCart className="h-10 w-10 text-slate-200" />
                                </div>
                                <p className="text-slate-400 font-bold uppercase tracking-widest text-xs">No orders found</p>
                            </div>
                        ) : (
                            filteredOrders.map((order) => (
                                <div 
                                    key={order.id}
                                    className={`group relative bg-white border border-slate-100 rounded-[2rem] p-6 transition-all duration-300 hover:border-emerald-200 hover:shadow-xl hover:shadow-emerald-600/5 border-l-4 ${order.status === 'success' ? 'border-l-emerald-500' : 'border-l-amber-500'} shadow-sm`}
                                >
                                    <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
                                        <div className="flex-1 space-y-4">
                                            <div className="flex flex-wrap items-center gap-3">
                                                <h3 className="text-xl font-black text-slate-900 tracking-tight uppercase">{order.plan_name}</h3>
                                                <Badge className={`${order.status === 'success' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-amber-50 text-amber-600 border-amber-100'} font-black rounded-full px-3 py-0.5 text-[10px] uppercase gap-1.5 flex items-center`}>
                                                    <div className={`w-1.5 h-1.5 rounded-full ${order.status === 'success' ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'}`} />
                                                    {order.status}
                                                </Badge>
                                                {order.is_allocated === 'allocated' && (
                                                    <Badge className="bg-indigo-50 text-indigo-600 border-indigo-100 font-black rounded-full px-3 py-0.5 text-[10px] uppercase gap-1.5 flex items-center">
                                                        <UserCheck className="w-3 h-3" />
                                                        Allocated
                                                    </Badge>
                                                )}
                                            </div>

                                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-y-4 gap-x-8">
                                                <div className="flex items-center gap-2.5">
                                                    <Calendar className="w-4 h-4 text-slate-400" />
                                                    <span className="text-[13px] font-bold text-slate-500 tracking-tight">{formatDate(order.created_at)}</span>
                                                </div>
                                                <div className="flex items-center gap-2.5">
                                                    <Box className="w-4 h-4 text-slate-400" />
                                                    <span className="text-[13px] font-bold text-slate-500 tracking-tight">{order.credits.toLocaleString()} Credits</span>
                                                </div>
                                                <div className="flex items-center gap-2.5">
                                                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-widest"># {order.txnid}</span>
                                                </div>
                                            </div>

                                            {order.allocated_to_user_id && (
                                                <div className="mt-4 p-3 bg-emerald-50 rounded-2xl border border-emerald-100/50 flex items-center gap-3 animate-in slide-in-from-left-2 duration-500">
                                                    <div className="p-1.5 bg-white rounded-lg shadow-sm">
                                                        <ChevronRight className="w-3 h-3 text-emerald-600" />
                                                    </div>
                                                    <p className="text-[11px] font-bold text-emerald-800 tracking-tight">
                                                        Allocated to: <span className="font-black opacity-80 select-all">{order.allocated_to_user_id}</span>
                                                    </p>
                                                </div>
                                            )}
                                        </div>

                                        <div className="flex flex-row md:flex-col items-center md:items-end justify-between md:justify-start gap-4 h-full">
                                            <div className="text-3xl font-black text-slate-900 tracking-tighter tabular-nums">
                                                ₹{order.amount.toLocaleString()}
                                            </div>
                                            <Button variant="ghost" size="sm" className="rounded-xl px-4 font-black text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 group">
                                                Details
                                                <ChevronRight className="w-4 h-4 ml-1 transition-transform group-hover:translate-x-0.5" />
                                            </Button>
                                        </div>
                                    </div>
                                </div>
                            ))
                        )}

                        {!isLoading && filteredOrders.length > 0 && (
                            <div className="pt-8 flex justify-center">
                                <Button variant="outline" onClick={fetchOrders} className="rounded-2xl px-12 h-12 border-slate-200 text-slate-500 font-bold hover:bg-slate-50 hover:text-slate-900 border-2 border-dashed">
                                    Refresh Orders
                                </Button>
                            </div>
                        )}
                    </div>
                </CardContent>
            </Card>
        </div>
    )
}
