"use client"

import React, { useState, useEffect } from "react"
import { 
    Users, Search, Filter, MoreVertical, Eye, Edit2, 
    Trash2, UserPlus, ArrowUpDown, ChevronLeft, 
    ChevronRight, CheckCircle2, XCircle, Clock
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { getGlobalUsers } from "../../../config/api";

export default function AdminUsersPage() {
    const [searchQuery, setSearchQuery] = useState("")
    const [users, setUsers] = useState<any[]>([])
    const [loading, setLoading] = useState(true)

    useEffect(() => {
        const fetchUsers = async () => {
            try {
                const data = await getGlobalUsers();
                setUsers(data);
            } catch (err) {
                console.error("Failed to load users", err);
            } finally {
                setLoading(false);
            }
        };
        fetchUsers();
    }, []);

    const getStatusBadge = (status: string) => {
        switch (status) {
            case "active":
                return <Badge className="bg-emerald-500/10 text-emerald-600 border-emerald-500/20 px-2 py-0.5"><CheckCircle2 className="w-3 h-3 mr-1" /> Active</Badge>
            case "inactive":
                return <Badge className="bg-rose-500/10 text-rose-600 border-rose-500/20 px-2 py-0.5"><XCircle className="w-3 h-3 mr-1" /> Inactive</Badge>
            case "pending":
                return <Badge className="bg-amber-500/10 text-amber-600 border-amber-500/20 px-2 py-0.5"><Clock className="w-3 h-3 mr-1" /> Pending</Badge>
            default:
                return <Badge className="bg-slate-500/10 text-slate-600 border-slate-500/20 px-2 py-0.5">{status}</Badge>
        }
    }

    if (loading) {
        return (
            <div className="flex h-screen items-center justify-center space-x-2">
                 <div className="w-8 h-8 rounded-full border-4 border-indigo-600 border-t-transparent animate-spin"></div>
                 <p className="font-bold text-slate-500">Loading User Directory...</p>
            </div>
        );
    }

    return (
        <div className="p-6 space-y-8 animate-in fade-in duration-500 max-w-[1600px] mx-auto">
            {/* Header Area */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-8 rounded-[2rem] shadow-xl shadow-slate-200/50 dark:shadow-none border border-slate-100 dark:border-slate-800">
                <div className="space-y-1">
                    <h1 className="text-3xl font-black tracking-tight text-slate-900 dark:text-white flex items-center gap-3">
                        <Users className="w-8 h-8 text-indigo-600" />
                        User Directory
                    </h1>
                    <p className="text-slate-500 font-bold uppercase tracking-[0.2em] text-[10px]">Infrastructure Management • Users</p>
                </div>
                <Button className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold px-6 py-6 rounded-2xl shadow-lg shadow-indigo-600/25 transition-all hover:scale-105 active:scale-95 flex items-center gap-2">
                    <UserPlus className="w-5 h-5" />
                    Register New User
                </Button>
            </div>

            {/* Content Card */}
            <Card className="border-none shadow-2xl shadow-slate-200/60 rounded-[2.5rem] overflow-hidden bg-white/80 backdrop-blur-xl">
                <CardHeader className="p-8 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-6">
                    <div className="relative w-full md:w-[400px] group">
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 group-focus-within:text-indigo-600 transition-colors" />
                        <Input 
                            placeholder="Search users, email, or companies..." 
                            className="pl-12 h-14 bg-slate-50/50 border-slate-100 rounded-2xl focus:ring-4 focus:ring-indigo-600/10 focus:border-indigo-600 transition-all font-medium"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                        />
                    </div>
                    <div className="flex items-center gap-3 overflow-x-auto pb-2 md:pb-0">
                        <Button variant="outline" className="h-12 rounded-xl border-slate-200 font-bold text-slate-600 hover:bg-slate-50">
                            <Filter className="w-4 h-4 mr-2" /> All Status
                        </Button>
                        <Button variant="outline" className="h-12 rounded-xl border-slate-200 font-bold text-slate-600 hover:bg-slate-50">
                            <Filter className="w-4 h-4 mr-2" /> All Roles
                        </Button>
                        <Button variant="outline" className="h-12 px-4 rounded-xl border-slate-200 font-bold text-slate-400">
                            <MoreVertical className="w-5 h-5" />
                        </Button>
                    </div>
                </CardHeader>
                <CardContent className="p-0">
                    <div className="overflow-x-auto">
                        <table className="w-full text-left">
                            <thead>
                                <tr className="bg-slate-50/50 border-b border-slate-100">
                                    <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-slate-500">
                                        <div className="flex items-center gap-2 cursor-pointer hover:text-indigo-600 transition-colors group">
                                            User Info <ArrowUpDown className="w-3 h-3" />
                                        </div>
                                    </th>
                                    <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-slate-500">Company / Workspace</th>
                                    <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-slate-500">Status</th>
                                    <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-slate-500">Member Since</th>
                                    <th className="px-8 py-5 text-[10px] font-black uppercase tracking-widest text-slate-500 text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-50">
                                {users.length > 0 ? users.filter(u => u.name.toLowerCase().includes(searchQuery.toLowerCase()) || u.email.toLowerCase().includes(searchQuery.toLowerCase())).map((user) => (
                                    <tr key={user.id} className="group hover:bg-slate-50/50 transition-colors duration-200">
                                        <td className="px-8 py-6">
                                            <div className="flex items-center gap-4">
                                                <Avatar className="h-12 w-12 border-2 border-white shadow-md">
                                                    <AvatarFallback className="bg-indigo-100 text-indigo-700 font-black text-xs uppercase">
                                                        {user.name ? user.name.slice(0, 2) : "US"}
                                                    </AvatarFallback>
                                                </Avatar>
                                                <div className="min-w-0">
                                                    <p className="font-black text-slate-900 truncate tracking-tight">{user.name}</p>
                                                    <p className="text-xs font-bold text-slate-400 truncate">{user.email}</p>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-8 py-6">
                                            <div className="space-y-1">
                                                <p className="text-sm font-black text-slate-700">{user.company}</p>
                                                <p className="text-[10px] uppercase font-black tracking-widest text-indigo-500/70">{user.role}</p>
                                            </div>
                                        </td>
                                        <td className="px-8 py-6">
                                            {getStatusBadge(user.status)}
                                        </td>
                                        <td className="px-8 py-6">
                                            <p className="text-sm font-bold text-slate-600">{user.joined !== "Unknown" ? new Date(user.joined).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : "Unknown"}</p>
                                        </td>
                                        <td className="px-8 py-6 text-right">
                                            <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity translate-x-4 group-hover:translate-x-0 transform duration-300">
                                                <Button variant="ghost" size="icon" className="h-10 w-10 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl" title="View Details">
                                                    <Eye className="w-5 h-5" />
                                                </Button>
                                                <Button variant="ghost" size="icon" className="h-10 w-10 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-xl" title="Edit Account">
                                                    <Edit2 className="w-5 h-5" />
                                                </Button>
                                                <Button variant="ghost" size="icon" className="h-10 w-10 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl" title="Delete Account">
                                                    <Trash2 className="w-5 h-5" />
                                                </Button>
                                            </div>
                                        </td>
                                    </tr>
                                )) : (
                                    <tr>
                                        <td colSpan={5} className="px-8 py-10 text-center text-slate-400 font-bold">
                                            No users found.
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>

                    {/* Pagination */}
                    <div className="p-8 border-t border-slate-100 flex flex-col md:flex-row items-center justify-between gap-4">
                        <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Showing {users.length > 0 ? 1 : 0} to {users.length} of {users.length} users</p>
                        <div className="flex items-center gap-2">
                            <Button variant="outline" className="w-10 h-10 p-0 rounded-xl border-slate-200 text-slate-400" disabled>
                                <ChevronLeft className="w-5 h-5" />
                            </Button>
                            {[1, 2, 3].map(p => (
                                <Button 
                                    key={p} 
                                    variant={p === 1 ? 'default' : 'outline'} 
                                    className={`w-10 h-10 p-0 rounded-xl font-bold transition-all ${p === 1 ? 'bg-indigo-600 shadow-lg shadow-indigo-600/20' : 'border-slate-200 text-slate-600 hover:bg-slate-50'}`}
                                >
                                    {p}
                                </Button>
                            ))}
                            <Button variant="outline" className="w-10 h-10 p-0 rounded-xl border-slate-200 text-slate-600 hover:bg-slate-50">
                                <ChevronRight className="w-5 h-5" />
                            </Button>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </div>
    )
}
