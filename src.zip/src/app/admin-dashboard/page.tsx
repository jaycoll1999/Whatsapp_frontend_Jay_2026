"use client"

import { 
    Users, CreditCard, ShoppingCart, 
    ArrowUpRight, ArrowDownRight, 
    MoreHorizontal, Share2, 
    Activity, Globe, User, 
    Wallet, TrendingUp, BarChart3,
    ArrowRight, ShieldCheck
} from "lucide-react";

import React from "react";
import { getAdminAnalytics, getResellers } from "../../config/api";

export default function AdminDashboardPage() {
  const [analytics, setAnalytics] = React.useState<any>(null);
  const [resellers, setResellers] = React.useState<any[]>([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await getAdminAnalytics();
        const resellerData = await getResellers();
        setAnalytics(data);
        setResellers(resellerData);
      } catch (err) {
        console.error('Failed to load admin data', err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

    return (
        <div className="space-y-8 animate-in fade-in duration-700">
            
            {/* ── Welcome Header ── */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Welcome back, Admin</h1>
                    <p className="text-slate-500 font-medium mt-1">Here's what's happening with your platform today.</p>
                </div>
                <div className="flex items-center gap-3">
                    <button className="px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-700 hover:bg-slate-50 transition-all flex items-center gap-2 shadow-sm">
                        <Share2 className="w-4 h-4" />
                        Export Report
                    </button>
                    <button className="px-4 py-2 bg-indigo-600 rounded-xl text-sm font-bold text-white hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 flex items-center gap-2">
                        <Activity className="w-4 h-4" />
                        Live Status
                    </button>
                </div>
            </div>

            {/* ── Statistics Cards ── */}
            {loading ? (
                <div className="flex items-center justify-center p-8"><p className="text-slate-500 font-bold">Loading dashboard metrics...</p></div>
            ) : analytics && analytics.kpis && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {[
                        { label: "Total Resellers", value: analytics.kpis.total_resellers, trend: "Active", icon: Users, color: "bg-blue-500" },
                        { label: "Direct Business Users", value: analytics.kpis.direct_business_users, trend: "Active", icon: User, color: "bg-indigo-500" },
                        { label: "Indirect Business Users", value: analytics.kpis.indirect_business_users, trend: "Active", icon: Users, color: "bg-emerald-500" },
                        { label: "Total Platform Messages", value: analytics.kpis.total_platform_messages, trend: "Global", icon: BarChart3, color: "bg-purple-500" },
                    ].map((card, i) => (
                        <div key={i} className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow group">
                            <div className="flex items-center justify-between mb-4">
                                <div className={`p-3 rounded-2xl ${card.color} text-white shadow-lg shadow-${card.color.split('-')[1]}-200 group-hover:scale-110 transition-transform`}>
                                    <card.icon className="w-5 h-5" />
                                </div>
                                <span className="text-xs font-bold px-2 py-1 rounded-lg text-emerald-600 bg-emerald-50">
                                    {card.trend}
                                </span>
                            </div>
                            <h3 className="text-slate-500 text-sm font-bold mb-1">{card.label}</h3>
                            <p className="text-2xl font-bold text-slate-900 tracking-tight">{card.value}</p>
                        </div>
                    ))}
                </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                
                {/* ── Usage Overview & Top Users ── */}
                <div className="lg:col-span-2 space-y-8">
                    
                    {/* Usage Overview (Progress bar) */}
                    <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
                        <div className="flex items-center justify-between mb-8">
                            <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                                <BarChart3 className="w-5 h-5 text-indigo-600" />
                                Usage Overview
                            </h2>
                            <select className="bg-slate-50 border-none text-sm font-bold text-slate-600 rounded-xl px-4 py-2 focus:ring-2 ring-indigo-500/20">
                                <option>Last 7 Days</option>
                                <option>Last 30 Days</option>
                            </select>
                        </div>
                        <div className="space-y-6">
                            {analytics && analytics.usage_breakdown ? (
                                [
                                    { name: "WhatsApp Campaigns", count: analytics.usage_breakdown.whatsapp_campaigns || 0, color: "bg-blue-500" },
                                    { name: "API Requests", count: analytics.usage_breakdown.api_requests || 0, color: "bg-indigo-500" }
                                ].map((item, i) => {
                                    const total = analytics.kpis?.total_platform_messages || 1;
                                    const percentage = Math.round((item.count / total) * 100) || 0;
                                    return (
                                        <div key={i} className="space-y-2">
                                            <div className="flex justify-between text-sm">
                                                <span className="font-bold text-slate-700">{item.name}</span>
                                                <span className="font-bold text-slate-500">{percentage}% Breakdown</span>
                                            </div>
                                            <div className="h-3 bg-slate-100 rounded-full overflow-hidden">
                                                <div 
                                                    className={`h-full ${item.color} rounded-full transition-all duration-1000`} 
                                                    style={{ width: `${percentage}%` }}
                                                />
                                            </div>
                                        </div>
                                    );
                                })
                            ) : null}
                        </div>
                    </div>

                    {/* Reseller Managed Users */}
                    <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
                        <div className="p-8 pb-4 flex items-center justify-between">
                            <h2 className="text-xl font-bold text-slate-900">Reseller Status</h2>
                            <button className="text-indigo-600 font-bold text-sm hover:underline">View All</button>
                        </div>
                        <div className="overflow-x-auto">
                            <table className="w-full">
                                <thead className="bg-slate-50/50">
                                    <tr>
                                        <th className="px-8 py-4 text-left text-xs font-bold text-slate-500 uppercase tracking-widest">Reseller Name</th>
                                        <th className="px-8 py-4 text-left text-xs font-bold text-slate-500 uppercase tracking-widest">Managed Users</th>
                                        <th className="px-8 py-4 text-left text-xs font-bold text-slate-500 uppercase tracking-widest">Available Credits</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-50">
                                    {(!loading && resellers.length > 0) ? resellers.map((r, i) => (
                                        <tr key={i} className="hover:bg-slate-50/50 transition-colors group">
                                            <td className="px-8 py-5">
                                                <div className="flex items-center gap-3">
                                                    <div className="w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm bg-blue-100 text-blue-600">
                                                        {r.name.charAt(0).toUpperCase()}
                                                    </div>
                                                    <div>
                                                        <p className="font-bold text-slate-900">{r.name}</p>
                                                        <p className="text-xs text-slate-500">{r.email}</p>
                                                    </div>
                                                </div>
                                            </td>
                                            <td className="px-8 py-5 font-bold text-slate-700">{r.user_count || 0} users</td>
                                            <td className="px-8 py-5 font-bold text-emerald-600">{r.credits} pts</td>
                                        </tr>
                                    )) : (
                                        <tr>
                                            <td colSpan={3} className="px-8 py-5 text-center text-slate-500 text-sm">No resellers found or loading...</td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                {/* ── Right Column: Transactions, Info, Source ── */}
                <div className="space-y-8">
                    
                    {/* Account Info (Admin) */}
                    <div className="bg-indigo-900 rounded-3xl border border-indigo-800 shadow-xl shadow-indigo-200/50 p-8 text-white relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-4 opacity-10">
                            <ShieldCheck className="w-24 h-24" />
                        </div>
                        <h3 className="text-indigo-300 text-xs font-bold uppercase tracking-[.2em] mb-4">Account Information</h3>
                        <div className="space-y-4 relative z-10">
                            <div className="flex items-center gap-4">
                                <div className="w-12 h-12 rounded-2xl bg-indigo-800/50 border border-indigo-500/30 flex items-center justify-center backdrop-blur-sm">
                                    <User className="w-6 h-6 text-indigo-400" />
                                </div>
                                <div>
                                    <p className="font-bold text-lg">System Admin</p>
                                    <p className="text-xs text-indigo-400 font-bold uppercase tracking-wider">Super Administrator</p>
                                </div>
                            </div>
                            <div className="grid grid-cols-2 gap-4 pt-4 border-t border-indigo-800">
                                <div>
                                    <p className="text-[10px] text-indigo-300 font-bold uppercase tracking-widest mb-1">User Type</p>
                                    <p className="font-bold">ADMIN</p>
                                </div>
                                <div>
                                    <p className="text-[10px] text-indigo-300 font-bold uppercase tracking-widest mb-1">Access Level</p>
                                    <p className="font-bold text-emerald-400">Owner</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* User Expiry Watchlist */}
                    <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
                        <h2 className="text-xl font-bold text-slate-900 mb-6 flex items-center gap-2">
                           <Activity className="w-5 h-5 text-rose-500" />
                           Approaching Expiry
                        </h2>
                        <div className="space-y-6">
                            {analytics && analytics.user_expiry_watchlist && analytics.user_expiry_watchlist.length > 0 ? (
                                analytics.user_expiry_watchlist.map((user: any, i: number) => (
                                    <div key={i} className="flex items-center justify-between">
                                        <div className="flex items-center gap-3">
                                            <div className="p-2 rounded-xl scale-90 bg-rose-50 text-rose-600">
                                                <ArrowDownRight className="w-4 h-4" />
                                            </div>
                                            <div>
                                                <p className="text-sm font-bold text-slate-900">{user.name}</p>
                                                <p className="text-[11px] text-slate-400 font-medium">{user.plan} • {user.type}</p>
                                            </div>
                                        </div>
                                        <p className="font-bold text-sm text-rose-600">{user.expires_at}</p>
                                    </div>
                                ))
                            ) : (
                                <p className="text-sm text-slate-500 text-center py-4">No users nearing expiration.</p>
                            )}
                        </div>
                    </div>

                    {/* Usage Stats Breakdown */}
                    <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
                        <h2 className="text-xl font-bold text-slate-900 mb-6 flex items-center gap-2">
                           <Globe className="w-5 h-5 text-indigo-600" />
                           Traffic Types
                        </h2>
                        <div className="space-y-4">
                            <div className="relative h-48 w-48 mx-auto flex items-center justify-center">
                                {/* Simplified visual */}
                                <div className="absolute inset-0 rounded-full border-[1.5rem] border-slate-100"></div>
                                <div className="absolute inset-0 rounded-full border-[1.5rem] border-blue-500 border-t-transparent border-r-transparent" style={{ transform: 'rotate(45deg)' }}></div>
                                <div className="absolute inset-0 flex items-center justify-center flex-col">
                                    <p className="text-2xl font-bold text-slate-900">{analytics?.kpis?.total_platform_messages || 0}</p>
                                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Messages</p>
                                </div>
                            </div>
                            <div className="flex justify-center gap-6 mt-4">
                                <div className="flex items-center gap-2">
                                    <div className="w-2.5 h-2.5 rounded-full bg-blue-500"></div>
                                    <span className="text-[11px] font-bold text-slate-500">Campaigns: {analytics?.usage_breakdown?.whatsapp_campaigns || 0}</span>
                                </div>
                                <div className="flex items-center gap-2">
                                    <div className="w-2.5 h-2.5 rounded-full bg-indigo-500"></div>
                                    <span className="text-[11px] font-bold text-slate-500">API: {analytics?.usage_breakdown?.api_requests || 0}</span>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    )
}
