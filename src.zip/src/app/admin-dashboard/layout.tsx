import AdminDashboardLayout from "@/components/layout/AdminDashboardLayout"

export default function Layout({ children }: { children: React.ReactNode }) {
    return (
        <AdminDashboardLayout>
            {children}
        </AdminDashboardLayout>
    )
}
