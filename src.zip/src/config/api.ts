// Base URLs for backend APIs
export const API_BASE_URL =
  process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000/api";

export const WHATSAPP_ENGINE_URL =
  process.env.NEXT_PUBLIC_WHATSAPP_ENGINE_URL || "http://localhost:3002";

// -------------------------------------------------
// Admin API helper functions
// -------------------------------------------------
import axios from "axios";

/** Admin login */
export const adminLogin = async (email: string, password: string) => {
  const response = await axios.post(`${API_BASE_URL}/admin/login`, {
    email,
    password,
  });
  // Store token for subsequent calls (you may adapt to your auth strategy)
  const token = response.data.access_token;
  axios.defaults.headers.common["Authorization"] = `Bearer ${token}`;
  return response.data;
};

/** Admin logout */
export const adminLogout = async () => {
  // Backend simply returns a message; we also clear stored token
  const response = await axios.post(`${API_BASE_URL}/admin/logout`);
  delete axios.defaults.headers.common["Authorization"];
  return response.data;
};

/** Get list of plans (optional category filter) */
export const getPlans = async (category?: string) => {
  const url = category
    ? `${API_BASE_URL}/admin/plans?category=${category}`
    : `${API_BASE_URL}/admin/plans`;
  const response = await axios.get(url);
  return response.data;
};

/** Create a new plan */
export const createPlan = async (plan: {
  name: string;
  price: number;
  credits_offered: number;
  validity_days: number;
  deduction_value: number;
  plan_category: string;
}) => {
  const response = await axios.post(`${API_BASE_URL}/admin/plans`, plan);
  return response.data;
};

/** Update an existing plan */
export const updatePlan = async (planId: string, plan: any) => {
  const response = await axios.put(`${API_BASE_URL}/admin/plans/${planId}`, plan);
  return response.data;
};

/** Delete a plan */
export const deletePlan = async (planId: string) => {
  const response = await axios.delete(`${API_BASE_URL}/admin/plans/${planId}`);
  return response.data;
};

/** Get admin analytics dashboard data */
export const getAdminAnalytics = async () => {
  const response = await axios.get(`${API_BASE_URL}/admin/analytics`);
  return response.data;
};

/** Get reseller hierarchy data */
export const getResellers = async () => {
  const response = await axios.get(`${API_BASE_URL}/admin/resellers`);
  return response.data;
};

/** Get Admin Profile data */
export const getAdminProfile = async () => {
  const response = await axios.get(`${API_BASE_URL}/admin/profile`);
  return response.data;
};

/** Update Admin Profile data */
export const updateAdminProfile = async (data: { name: string; phone: string; location: string; bio: string }) => {
  const response = await axios.put(`${API_BASE_URL}/admin/profile`, data);
  return response.data;
};

/** Get global user directory */
export const getGlobalUsers = async () => {
  const response = await axios.get(`${API_BASE_URL}/admin/users`);
  return response.data;
};

/** Get global audit logs for Admin */
export const getAdminAuditLogs = async (params: any = {}) => {
  const response = await axios.get(`${API_BASE_URL}/admin/audit-logs`, { params });
  return response.data;
};